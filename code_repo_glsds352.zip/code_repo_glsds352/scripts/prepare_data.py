#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
prepare_data.py — 构建 ISON 输入文件（论文同款过滤：filter_mat top-80% 按检出率）

输出结构：
  E:\space\ison_data\
  ├── rna.h5ad                共享参考：Multiome 32,243 细胞 × top-80% 基因（按检出细胞数）
  ├── atac.h5ad               共享参考：同 32,243 细胞 × top-80% peak
  └── {切片}/sprna.h5ad       每张 Visium：spots × top-80% 基因
      {切片}/coords.csv       每张 Visium：spots × (x,y)，index=barcode

用法：
  python prepare_data.py                     # 全部 12 张
  python prepare_data.py 159_C1 159_D1       # 只跑指定切片
"""
import os
import sys
import zipfile
import numpy as np
import pandas as pd
import scipy.sparse as sp
import scanpy as sc

DATA_DIR = r'E:\space\data'
OUT_DIR  = r'E:\space\ison_data'
MULTIOME_H5 = os.path.join(DATA_DIR, 'GLDS-352_snRNA-Seq_filtered_feature_bc_matrix (1).h5')
VISIUM_ZIP  = os.path.join(DATA_DIR, 'GLDS-352_SpatialTranscriptomics_visium_data(1).zip')
EXTRACT_DIR = os.path.join(OUT_DIR, '_visium_extract')

# 12 张 Visium 切片（样本配对表）
ALL_SLICES = ['159_A1','159_B1','159_C1','159_D1',
              '158_A1','158_B1','158_C1','158_D1',
              '304_A1','304_B1','304_C1','304_D1']


def filter_mat(adata, name=''):
    """论文 preprocess.filter_mat 的等价实现：按检出细胞数取 top-80 百分位。
    官方实现 `np.sum(X.A > 0, axis=0)` 会稠密化全矩阵（内存爆炸）；
    这里用稀疏 getnnz，数学等价（每特征非零计数 = 检出细胞数），零额外内存。"""
    X = adata.X
    if sp.issparse(X):
        a1 = np.asarray(X.getnnz(axis=0))
    else:
        a1 = np.sum(X > 0, axis=0).astype(int)
    cut1 = np.percentile(a1, 80)
    keep = a1 > cut1
    print(f'  [{name}] 检出数 p80 = {cut1}，保留 {keep.sum()} / {len(a1)} 特征')
    return adata[:, keep].copy()


def remove_mito(adata):
    mt = adata.var_names.str.lower().str.startswith('mt')
    n = int(mt.sum())
    if n:
        print(f'  [remove_mito] 去掉 {n} 个 mt 基因')
    return adata[:, ~mt].copy()


def build_reference():
    """共享参考：rna.h5ad + atac.h5ad（Multiome 全部 32,243 细胞）"""
    print('===== 构建共享参考 =====')
    os.makedirs(OUT_DIR, exist_ok=True)
    if os.path.exists(os.path.join(OUT_DIR, 'rna.h5ad')) and os.path.exists(os.path.join(OUT_DIR, 'atac.h5ad')):
        print('rna.h5ad / atac.h5ad 已存在，跳过。删除可重建。')
        return

    print('读取 Multiome h5 ...')
    ad = sc.read_10x_h5(MULTIOME_H5, gex_only=False)
    print(f'  Multiome 形状: {ad.shape}')

    mask_ge = (ad.var['feature_types'] == 'Gene Expression').values
    mask_pk = (ad.var['feature_types'] == 'Peaks').values

    rna = ad[:, mask_ge].copy()
    atac = ad[:, mask_pk].copy()

    # symbol 去重 + 去线粒体 + 过滤
    n_dup = int(rna.var_names.duplicated().sum())
    print(f'  GE 重复 symbol: {n_dup}（去重）')
    rna = rna[:, ~rna.var_names.duplicated()].copy()
    rna = remove_mito(rna)
    rna = filter_mat(rna, name='rna(GE)')

    n_dup_pk = int(atac.var_names.duplicated().sum())
    print(f'  Peaks 重复: {n_dup_pk}（去重）')
    atac = atac[:, ~atac.var_names.duplicated()].copy()
    atac = filter_mat(atac, name='atac(Peaks)')

    # 确保 rna 和 atac 的 obs 完全一致（同一来源，应天然一致）
    assert (rna.obs_names == atac.obs_names).all(), 'rna/atac barcode 不一致！'

    rna.write_h5ad(os.path.join(OUT_DIR, 'rna.h5ad'))
    atac.write_h5ad(os.path.join(OUT_DIR, 'atac.h5ad'))
    print(f'  已写: rna.h5ad {rna.shape} / atac.h5ad {atac.shape}')
    print(f'  参考 barcode 前3: {list(rna.obs_names[:3])}')


def build_slice(sname):
    """单张 Visium：sprna.h5ad + coords.csv"""
    print(f'\n===== 切片 {sname} =====')
    os.makedirs(os.path.join(OUT_DIR, sname), exist_ok=True)
    os.makedirs(EXTRACT_DIR, exist_ok=True)

    # 1) 从 zip 解出 h5 + tissue_positions
    z = zipfile.ZipFile(VISIUM_ZIP)
    h5_name = f'visium_data/Sample_{sname}/filtered_feature_bc_matrix.h5'
    tp_name = f'visium_data/Sample_{sname}/tissue_positions_list.csv'
    for n in (h5_name, tp_name):
        try:
            z.extract(n, path=EXTRACT_DIR)
        except KeyError:
            print(f'  [ERROR] zip 中找不到 {n}')
            return

    # 2) sprna
    sprna = sc.read_10x_h5(os.path.join(EXTRACT_DIR, h5_name))
    print(f'  读 Visium h5: {sprna.shape}')
    n_dup = int(sprna.var_names.duplicated().sum())
    print(f'  重复 gene: {n_dup}（去重）')
    sprna = sprna[:, ~sprna.var_names.duplicated()].copy()
    sprna = remove_mito(sprna)
    sprna = filter_mat(sprna, name='sprna')

    # 3) coords（tissue_positions_list.csv 无表头）
    tp = pd.read_csv(os.path.join(EXTRACT_DIR, tp_name), header=None,
                     names=['barcode','in_tissue','array_row','array_col','pxl_col','pxl_row'])
    tp['in_tissue'] = pd.to_numeric(tp['in_tissue'], errors='coerce')
    tp = tp[tp['in_tissue'] == 1].copy()
    print(f'  in_tissue=1: {len(tp)}（h5 spots = {sprna.n_obs}）')

    # 4) coords 对齐 sprna barcode
    tp = tp[tp['barcode'].isin(sprna.obs_names)].copy()
    tp = tp.set_index('barcode')
    coords = pd.DataFrame({'x': tp['array_row'].astype(float),
                           'y': tp['array_col'].astype(float)},
                          index=tp.index)
    # 按 sprna 顺序对齐，缺的检查
    miss = set(sprna.obs_names) - set(coords.index)
    if miss:
        print(f'  [WARN] {len(miss)} 个 spot 在 coords 中缺失：{list(miss)[:5]}')
    coords = coords.loc[sprna.obs_names.intersection(coords.index)]

    # 5) 保存
    sprna.write_h5ad(os.path.join(OUT_DIR, sname, 'sprna.h5ad'))
    coords.to_csv(os.path.join(OUT_DIR, sname, 'coords.csv'), index=True)
    print(f'  已写: sprna.h5ad {sprna.shape} / coords.csv {coords.shape}')
    print(f'  coords 前3:')
    print(coords.head(3).to_string())


if __name__ == '__main__':
    slices = sys.argv[1:] or ALL_SLICES
    # 校验切片名
    bad = [s for s in slices if s not in ALL_SLICES]
    if bad:
        raise SystemExit(f'未知切片: {bad}')
    build_reference()
    for s in slices:
        build_slice(s)
    print('\n[DONE] 全部完成')
