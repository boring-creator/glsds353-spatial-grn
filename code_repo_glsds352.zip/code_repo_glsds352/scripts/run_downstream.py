# -*- coding: utf-8 -*-
"""run_downstream.py — 12 模块 K-means + FL vs GC logFC + GSEA（对应 ISON 论文 Fig 5d）
base env，cwd=/root/autodl-tmp/linger

用法：
  python run_downstream.py quick   # 只做模块 + logFC（快）
  python run_downstream.py gsea    # 只做 GSEA（每细胞类型 prerank，较慢，建议后台）
"""
import sys
import numpy as np
import pandas as pd
from scipy.stats import zscore
from sklearn.cluster import KMeans

out = "/root/autodl-tmp/linger/grn_out/"
work = "/root/autodl-tmp/linger/"
FL = {"158_A1", "158_B1", "158_C1", "158_D1", "159_C1", "159_D1"}

mode = sys.argv[1] if len(sys.argv) > 1 else "quick"

if mode in ("quick", "gsea"):
    # ---------- 1) 12 模块 K-means（trans 网络 z-score 后聚类基因）----------
    trans = pd.read_csv(out + "cell_population_trans_regulatory.txt", sep="\t", index_col=0)
    # 向量化 z-score（pandas 3 的 apply(axis=1) 行为变了，不用 apply）
    trans_z = (trans - trans.mean(axis=1)) / (trans.std(axis=1) + 1e-12)
    trans_z = trans_z.fillna(0)
    km = KMeans(n_clusters=12, random_state=42, n_init=10).fit(trans_z.values)
    modules = pd.DataFrame({"gene": trans.index, "module": km.labels_})
    modules.to_csv(work + "gene_modules.txt", sep="\t", index=None)
    print("模块大小:", dict(modules.groupby("module").size()), flush=True)

    # ---------- 2) FL vs GC logFC（按细胞类型）----------
    TG = pd.read_csv(work + "data/TG_pseudobulk.tsv", sep=",", index_col=0)
    gdf = pd.DataFrame({
        "group": TG.columns,
        "sample": [g.rsplit("_", 1)[0] for g in TG.columns],
        "ct": [g.rsplit("_", 1)[1] for g in TG.columns]})
    gdf["cond"] = gdf["sample"].apply(lambda s: "FL" if s in FL else "GC")
    cts = sorted(gdf["ct"].unique())
    logFC = pd.DataFrame(index=TG.index)
    for ct in cts:
        flg = gdf[(gdf.ct == ct) & (gdf.cond == "FL")]
        gcg = gdf[(gdf.ct == ct) & (gdf.cond == "GC")]
        if len(flg) > 0 and len(gcg) > 0:
            fl = TG[flg.group].mean(axis=1)
            gc = TG[gcg.group].mean(axis=1)
            logFC[ct] = np.log2((fl + 1) / (gc + 1))
    logFC.to_csv(work + "logFC_FLvsGC.txt", sep="\t")
    print(f"logFC: {logFC.shape[0]} 基因 × {logFC.shape[1]} 细胞类型", flush=True)

if mode == "quick":
    print("[DONE] quick 部分完成")
    sys.exit(0)

# ---------- 3) GSEA（每细胞类型一次 prerank，含全部 12 模块基因集）----------
import gseapy as gp
import os
module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}
tmpdir = work + "gsea_tmp/"
os.makedirs(tmpdir, exist_ok=True)
nes_rows = []
for ct in cts:
    r = logFC[ct].dropna()
    if len(r) < 10:
        continue
    ranks = r.sort_values(ascending=False)
    pre = gp.prerank(rnk=ranks, gene_sets=module_sets, min_size=3, max_size=2000,
                     permutation_num=1000, seed=42, no_plot=True, outdir=tmpdir)
    for _, row in pre.res2d.iterrows():
        nes_rows.append({"celltype": ct, "module": row["Term"],
                         "NES": row["NES"], "FWER_p": row["FWER p-val"]})
    print(f"  [{ct}] GSEA 完成", flush=True)
nes = pd.DataFrame(nes_rows)
nes.to_csv(work + "GSEA_NES_celltype_module.txt", sep="\t", index=None)
print(f"[DONE] GSEA 完成: {nes.shape}", flush=True)
print(nes.head(10).to_string(), flush=True)
