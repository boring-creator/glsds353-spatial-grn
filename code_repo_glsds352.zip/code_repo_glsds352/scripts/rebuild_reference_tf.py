# -*- coding: utf-8 -*-
"""rebuild_reference_tf.py — 重建共享参考 rna.h5ad，保留全部 TF。

问题背景：原 prepare_data.py 的 filter_mat（top-80% 按检出率）把低表达 TF
（Fos/Jun/Egr1/Nr4a2 等立即早期基因）从参考基因集过滤掉，导致 ISON 去噪 RNA
只覆盖 130/714 小鼠 TF。本脚本在 top-80% 过滤后，把 TFName.txt 中 Multiome
里存在的全部 TF 加回参考 → ISON 重跑后输出可覆盖全部在 ST 中检出的 TF（~217）。

只重建 rna.h5ad（atac.h5ad / sprna / coords 均不变）。旧 rna.h5ad 备份为
rna_old.h5ad。基于 ISON preprocess.prep(raw=False) 确认：ISON 不会再次过滤，
加回的 TF 能进入输出。

用法：
  E:/miniconda/envs/ison_env/python.exe rebuild_reference_tf.py
"""
import os
import numpy as np
import pandas as pd
import scipy.sparse as sp
import scanpy as sc

DATA_DIR = r'E:\space\data'
OUT_DIR  = r'E:\space\ison_data'
MULTIOME_H5 = os.path.join(DATA_DIR, 'GLDS-352_snRNA-Seq_filtered_feature_bc_matrix (1).h5')
TF_FILE = r'C:\Users\aguang\Downloads\Desktop\scnn\provide_data\TFName.txt'


def filter_mat(adata, name=''):
    X = adata.X
    if sp.issparse(X):
        a1 = np.asarray(X.getnnz(axis=0))
    else:
        a1 = np.sum(X > 0, axis=0).astype(int)
    cut1 = np.percentile(a1, 80)
    keep = a1 > cut1
    print(f'  [{name}] 检出数 p80 = {cut1}，保留 {keep.sum()} / {len(a1)} 特征')
    return adata[:, keep].copy()


def remove_mito(adata):
    mt = adata.var_names.str.lower().str.startswith('mt')
    n = int(mt.sum())
    if n:
        print(f'  [remove_mito] 去掉 {n} 个 mt 基因')
    return adata[:, ~mt].copy()


def main():
    print('===== 重建 rna.h5ad（保留 TF） =====')
    print('读取 Multiome h5 ...')
    ad = sc.read_10x_h5(MULTIOME_H5, gex_only=False)
    print(f'  Multiome: {ad.shape}')
    mask_ge = (ad.var['feature_types'] == 'Gene Expression').values
    rna = ad[:, mask_ge].copy()
    del ad

    n_dup = int(rna.var_names.duplicated().sum())
    print(f'  GE 重复 symbol: {n_dup}（去重，保留首个）')
    rna = rna[:, ~rna.var_names.duplicated()].copy()
    rna = remove_mito(rna)

    # 论文过滤 top-80%（等价原 prepare_data）
    rna_f = filter_mat(rna, name='rna(GE)')

    # 加回 TF：TFName.txt 中 Multiome 存在的全部 TF
    tf = pd.read_csv(TF_FILE, header=None, sep='\t')[0].values
    rna_genes = set(rna.var_names)
    tf_in = [g for g in tf if g in rna_genes]
    extra = [g for g in tf_in if g not in set(rna_f.var_names)]
    print(f'  TFName 中 Multiome 存在的 TF: {len(tf_in)} / {len(tf)}')
    print(f'  被 top-80% 过滤掉、现在加回的 TF: {len(extra)}')
    print(f'  加回示例: {extra[:15]}')

    # 保序合并（过滤基因在前，TF 补缺在后）
    keep = list(dict.fromkeys(list(rna_f.var_names) + tf_in))
    rna_new = rna[:, keep].copy()
    del rna

    n_tf = len(set(rna_new.var_names) & set(tf_in))
    print(f'  新 rna 参考: {rna_new.shape} | TF 覆盖: {n_tf} / {len(tf_in)}')

    # 备份旧文件
    old = os.path.join(OUT_DIR, 'rna.h5ad')
    if os.path.exists(old):
        bak = os.path.join(OUT_DIR, 'rna_old.h5ad')
        if os.path.exists(bak):
            os.remove(bak)
        os.rename(old, bak)
        print('  旧 rna.h5ad -> rna_old.h5ad')

    rna_new.write_h5ad(old)
    print(f'  已写: rna.h5ad {rna_new.shape}')

    # 验证：与各切片 sprna 的交集（预测 ISON 输出基因数 + TF 覆盖）
    tf_set = set(tf_in)
    print('  === 与 sprna 交集预测 ===')
    for s in ['158_A1', '159_C1', '304_A1']:
        sprna = sc.read_h5ad(os.path.join(OUT_DIR, s, 'sprna.h5ad'))
        inter = set(rna_new.var_names) & set(sprna.var_names)
        print(f'    {s}: 输出基因≈{len(inter)}，TF≈{len(inter & tf_set)}')
    sp = sc.read_h5ad(os.path.join(OUT_DIR, '159_C1', 'sprna.h5ad'))
    inter = set(rna_new.var_names) & set(sp.var_names)
    for g in ['Fos', 'Jun', 'Egr1', 'Nr4a2', 'Nr4a3', 'Klf7', 'Nr3c1']:
        print(f'    {g}: {"O" if g in inter else "X"}')


if __name__ == '__main__':
    main()
