# validate_marker_enhancer.R — 验证⑤：Marker 基因增强子/启动子 peak 识别
# 用 ChIPseeker 注释所有 peak，找海马/应激 marker 的启动子(<3kb)或增强子(3-50kb)peak
suppressMessages({
  library(ChIPseeker)
  library(GenomicFeatures)
  library(org.Mm.eg.db)
})

markers <- c("Nrgn", "Mbp", "Slc17a7", "Gad1", "Wfs1", "Egr1", "Nr3c1")

txdb <- loadDb("C:/Users/aguang/Downloads/Desktop/sci/mm10_txdb.sqlite")
peaks_txt <- readLines("C:/Users/aguang/Downloads/Desktop/sci/linger_outputs/Peaks.txt")
peaks_txt <- peaks_txt[nchar(peaks_txt) > 0]
gr <- GRanges(
  seqnames = sub(":.*", "", peaks_txt),
  ranges = IRanges(
    start = as.integer(sub(".*:(\\d+)-.*", "\\1", peaks_txt)),
    end = as.integer(sub(".*-(\\d+)$", "\\1", peaks_txt))
  )
)
names(gr) <- peaks_txt
keep <- seqnames(gr) %in% paste0("chr", c(1:19, "X", "Y"))
gr <- gr[keep]

anno <- annotatePeak(gr, TxDb = txdb, level = "gene", verbose = FALSE)
df <- as.data.frame(anno)
ens <- sub("\\..*$", "", df$geneId)
sym <- mapIds(org.Mm.eg.db, keys = ens, keytype = "ENSEMBL", column = "SYMBOL", multiVals = "first")
df$SYMBOL <- as.character(sym)
df$peak <- names(gr)

# 对每个 marker：找启动子(<3kb) / 增强子(3-50kb) peak
results <- data.frame()
for (m in markers) {
  sub <- df[!is.na(df$SYMBOL) & df$SYMBOL == m, ]
  prom <- sub[abs(sub$distanceToTSS) <= 3000, "peak"]
  enh  <- sub[abs(sub$distanceToTSS) > 3000 & abs(sub$distanceToTSS) <= 50000, "peak"]
  results <- rbind(results, data.frame(marker = m,
    n_promoter = length(prom), n_enhancer = length(enh),
    top_promoter = ifelse(length(prom) > 0, prom[1], NA),
    top_enhancer = ifelse(length(enh) > 0, enh[1], NA)))
}
cat("=== Marker peak 识别 ===\n")
print(results, row.names = FALSE)
write.csv(results, "C:/Users/aguang/Downloads/Desktop/sci/marker_peaks.csv", row.names = FALSE)
cat("已保存 marker_peaks.csv\n")
