#!/usr/bin/env Rscript
# run_nes_heatmap.R — 模块 GSEA 的 NES 热图（对应 ISON 论文 Fig 5d）
# 左图 = 动物级 FL vs GC（n=3 每组，消除切片级伪重复）
# 右图 = 159 批次内部对照（G7 vs F1，1 vs 1 动物 → direction-only，无 FWER 星号）
# 模块顺序与图三统一；色阶 ±3；细胞类型用 RR3 区域短名
suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(patchwork))

base <- "C:/Users/aguang/Downloads/Desktop/sci"
full <- read.delim(file.path(base, "linger_outputs/GSEA_NES_animal.txt"))
c159 <- read.delim(file.path(base, "linger_outputs/GSEA_159_control.tsv"))

mod_order <- c("M11", "M5", "M8", "M3", "M2", "M6", "M9")   # 与图三对齐
# 细胞类型编号 → RR3 主导区域短名（图注给映射说明）
ct_names <- c("0"="0 SomMot/Vis ctx", "1"="1 Hypo/Pit", "2"="2 Pirif/amyg",
              "4"="4 White matter", "5"="5 CA1 radiatum", "6"="6 CA3",
              "7"="7 Thalamus", "8"="8 Hypo/Pit", "9"="9 Midbrain GABA",
              "11"="11 Pirif/amyg")
ct_order <- names(ct_names)

prep <- function(d, direction_only = FALSE) {
  d$celltype <- factor(ct_names[as.character(d$celltype)], levels = ct_names)
  d$module   <- factor(d$module,   levels = mod_order)
  if (direction_only) {                        # 1 vs 1 动物 → 只标方向，无星号
    d$sig <- ""
  } else {
    d$sig <- ifelse(d$FWER_p < 0.05, "*", "")
  }
  d$label <- sprintf("%.1f%s", d$NES, d$sig)
  d
}

plot_nm <- function(d, title, show_legend = TRUE) {
  ggplot(d, aes(celltype, module, fill = NES)) +
    geom_tile(color = "white", linewidth = 0.6) +
    geom_text(aes(label = label), size = 2.8) +
    scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b",
                         midpoint = 0, limits = c(-3, 3), oob = scales::squish,
                         name = "NES\n(Normalized\nEnrichment Score)",
                         guide = if (show_legend) "colourbar" else "none") +
    scale_y_discrete(limits = rev(mod_order)) +
    labs(x = "cell type (region annotation)", y = "GRN module", title = title) +
    theme_minimal(base_size = 11) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6.5),
          axis.text.y = element_text(size = 9),
          axis.title = element_text(size = 10),
          panel.grid = element_blank(),
          plot.title = element_text(hjust = 0.5, face = "bold", size = 11))
}

p1 <- plot_nm(prep(full),
              "A | FL vs GC (animal-level, n = 3 per group)",
              show_legend = FALSE)
p2 <- plot_nm(prep(c159, direction_only = TRUE),
              "B | Batch-internal control (G7 vs F1, direction-only)",
              show_legend = TRUE)

out <- p1 + p2 + plot_layout(widths = c(1, 1)) +
  plot_annotation(
    title = "Module-level GSEA: * = FWER < 0.05 (left panel only); red = FL up, blue = GC up",
    subtitle = "Left: animal-level (n = 3 per group). Right: direction-only (F1 vs G7, one animal each).",
    theme = theme(plot.title = element_text(hjust = 0.5, size = 12),
                  plot.subtitle = element_text(hjust = 0.5, size = 8.5, color = "grey25")))
ggsave(file.path(base, "figures/Fig4_NES_FLvsGC.png"), out,
       width = 15, height = 6, dpi = 300)
cat("[DONE] figures/Fig4_NES_FLvsGC.png\n")
