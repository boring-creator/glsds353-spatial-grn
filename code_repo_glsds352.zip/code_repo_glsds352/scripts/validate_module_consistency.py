# -*- coding: utf-8 -*-
"""validate_module_consistency.py — 验证①：RNA-ATAC 模块一致性（论文 Methods 复现）

论文（ISON）：
  1. W1（peaks×modules）/ W2（genes×modules）归一化：列除以列和（同幅度），行转为占比（行和为1）
  2. 每模块选 top 800 peaks（W1）/ top 200 genes（W2）
  3. 每 spot：基因程序模块比例 vs 染色质可及性程序模块比例
  4. 逐 spot 相关（论文 Fig S22b：mean≈0.87, median≈0.91）+ 置换检验

用法：E:/miniconda/envs/valenv/python.exe validate_module_consistency.py [切片]
"""
import os
import sys
import numpy as np
import pandas as pd
import scanpy as sc
from scipy.stats import pearsonr

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "ison_outputs_v2")
N_PEAKS = 800
N_GENES = 200
SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]

def normalize_W(W):
    """论文归一化：列除以列和（同幅度）→ 行转为占比（行和为1）"""
    W = W / W.sum(axis=0, keepdims=True)         # 列同幅度
    W = W / W.sum(axis=1, keepdims=True)         # 行占比
    return W

def assign_modules(W1, W2, peak_names, gene_names):
    """每模块选 top N peaks / top N genes"""
    W1n = normalize_W(W1)
    W2n = normalize_W(W2)
    n_mod = min(W1.shape[1], W2.shape[1])   # 取共享模块数
    W1n = W1n[:, :n_mod]
    W2n = W2n[:, :n_mod]
    peak_modules = {}   # module -> set of top peaks
    gene_modules = {}
    for k in range(n_mod):
        pk = peak_names[np.argsort(-W1n[:, k])[:N_PEAKS]]
        gn = gene_names[np.argsort(-W2n[:, k])[:N_GENES]]
        peak_modules[k] = set(pk)
        gene_modules[k] = set(gn)
    return peak_modules, gene_modules, n_mod

def proportions(peak_modules, gene_modules, atac, rna, n_mod):
    """每 spot 的 ATAC 模块比例 + RNA 模块比例"""
    peak_pos = {p: i for i, p in enumerate(atac.var_names)}
    gene_pos = {g: i for i, g in enumerate(rna.var_names)}
    Xa = np.asarray(atac.X)
    Xr = np.asarray(rna.X)
    P_a = np.zeros((Xa.shape[0], n_mod))
    P_r = np.zeros((Xr.shape[0], n_mod))
    for k in range(n_mod):
        pk = [peak_pos[p] for p in peak_modules[k] if p in peak_pos]
        gn = [gene_pos[g] for g in gene_modules[k] if g in gene_pos]
        if pk:
            P_a[:, k] = Xa[:, pk].sum(axis=1)
        if gn:
            P_r[:, k] = Xr[:, gn].sum(axis=1)
    # 行归一化（占比）
    P_a = P_a / (P_a.sum(axis=1, keepdims=True) + 1e-12)
    P_r = P_r / (P_r.sum(axis=1, keepdims=True) + 1e-12)
    return P_a, P_r

if __name__ == "__main__":
    targets = sys.argv[1:] or SLICES
    results = {}
    for s in targets:
        wp = os.path.join(OUT, s, "weights.pt")
        ap = os.path.join(OUT, s, f"{s}-ATAC.h5ad")
        rp = os.path.join(OUT, s, f"{s}-RNA.h5ad")
        if not all(os.path.exists(p) for p in [wp, ap, rp]):
            print(f"[SKIP] {s}")
            continue
        npz = np.load(os.path.join(OUT, "npz", f"{s}.npz"))
        W1 = npz["W1"]
        W2 = npz["W2"]
        atac = sc.read_h5ad(ap)
        rna = sc.read_h5ad(rp)
        peak_modules, gene_modules, n_mod = assign_modules(W1, W2, atac.var_names, rna.var_names)
        P_a, P_r = proportions(peak_modules, gene_modules, atac, rna, n_mod)
        # 保存模块分配（② Fisher 用）：每个 peak/gene 归到其 top 模块
        W1n = normalize_W(W1)[:, :n_mod]
        W2n = normalize_W(W2)[:, :n_mod]
        peak_top = pd.DataFrame({"peak": atac.var_names, "module": W1n.argmax(axis=1)})
        gene_top = pd.DataFrame({"gene": rna.var_names, "module": W2n.argmax(axis=1)})
        peak_top.to_csv(os.path.join(BASE, "module_assign_peak.tsv"), sep="\t", index=None)
        gene_top.to_csv(os.path.join(BASE, "module_assign_gene.tsv"), sep="\t", index=None)
        if s == targets[0]:
            print(f"  模块分配已存: peak({peak_top.shape}) gene({gene_top.shape})")
        cors = [pearsonr(P_a[i], P_r[i])[0] for i in range(P_a.shape[0])]
        results[s] = cors
        print(f"=== {s}: {n_mod} 模块, {P_a.shape[0]} spots ===")
        print(f"  模块比例相关: mean={np.mean(cors):.3f}, median={np.median(cors):.3f}, >0.5比例={(np.array(cors)>0.5).mean()*100:.1f}%")
    if results:
        all_c = np.concatenate(list(results.values()))
        print(f"\n=== 汇总: mean={np.mean(all_c):.3f}, median={np.median(all_c):.3f} ===")
        # 保存：每切片逐 spot 相关（图二用）
        rows = []
        for s, cors in results.items():
            for i, c in enumerate(cors):
                rows.append({"slice": s, "spot_idx": i, "corr": c})
        pd.DataFrame(rows).to_csv(
            os.path.join(BASE, "linger_outputs", "module_consistency_results.tsv"),
            sep="\t", index=None)
        print("[SAVED] linger_outputs/module_consistency_results.tsv")
