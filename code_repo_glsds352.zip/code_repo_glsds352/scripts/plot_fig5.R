#!/usr/bin/env Rscript
# plot_fig5.R — 图六：关键应激基因空间表达 FL vs GC（纯转录组，159 批次）
#   行 = FL(159_C1) / GC(159_A1)；列 = Egr1 / Nr3c1 / Nrgn
#   每基因 FL/GC 共享色阶（直接可比）；不含 ATAC
suppressMessages({library(ggplot2); library(patchwork)})
base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
dat <- read.csv(file.path(base, "marker_159_data.csv"))

FL_SLICE <- "159_C1"; GC_SLICE <- "159_A1"
KEY <- c("Egr1", "Nr3c1", "Nrgn")

sp <- function(d, title, lim) {
  ggplot(d, aes(x, y, color = value)) +
    geom_point(size = 1.0, alpha = 0.85) +
    scale_color_gradient(low = "grey90", high = "darkred", name = "Expr",
                         limits = c(0, lim), oob = scales::squish) +
    labs(title = title) + coord_fixed() + theme_void() +
    theme(plot.title = element_text(size = 10, face = "bold", hjust = 0.5),
          legend.key.size = unit(0.3, "cm"), legend.text = element_text(size = 6.5))
}

# 每基因 FL/GC 共享色阶上限（取两切片共同最大值）
grid <- list()
for (g in KEY) {
  sub <- dat[dat$marker == g, ]
  ex <- data.frame(x = sub$x, y = sub$y, value = sub$expr, slice = sub$slice)
  lim <- max(ex$value[ex$slice %in% c(FL_SLICE, GC_SLICE)])
  fl <- sp(ex[ex$slice == FL_SLICE, ], paste0("FL (F1) ", g), lim)
  gc <- sp(ex[ex$slice == GC_SLICE, ], paste0("GC (G7) ", g), lim)
  grid[[g]] <- fl / gc
}

fig <- wrap_plots(grid, nrow = 1) +
  plot_annotation(
    title = "Figure 6 | Stress genes: spatial expression, FL vs GC (batch 159, G7 vs F1)",
    subtitle = "Spatial mRNA expression (transcriptome only). Shared color scale per gene. Descriptive (1 section per condition).",
    theme = theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"),
                  plot.subtitle = element_text(hjust = 0.5, size = 8.5, color = "grey25")))
ggsave(file.path(outdir, "Fig6_key_genes_FLvsGC.png"), fig,
       width = 13, height = 9, dpi = 300, limitsize = FALSE)
cat("[DONE] figures/Fig6_key_genes_FLvsGC.png\n")
