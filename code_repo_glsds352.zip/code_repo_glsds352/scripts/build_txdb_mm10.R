library(GenomicFeatures)
gtf <- "E:/space/LINGER_ref/mm10.ncbiRefSeq.gtf.gz"
cat("从 RefSeq GTF 构建 mm10 TxDb ...\n", flush=TRUE)
txdb <- makeTxDbFromGFF(gtf, format="gtf", organism="Mus musculus")
cat("构建完成，保存 ...\n", flush=TRUE)
saveDb(txdb, "mm10_txdb.sqlite")
cat("已保存 mm10_txdb.sqlite\n", flush=TRUE)
