# -*- coding: utf-8 -*-
"""validate_distance_decay.py — 验证③：顺式调控距离衰减（论文 Fig 3a 做法）

peak-gene 按基因组距离分箱，各箱内算"预测 ATAC(peak) vs 去噪 RNA(gene)"跨 spot 的相关系数。
预期：距离越近相关越强（衰减曲线）。

输入：
  linger_outputs/RE_gene_distance.txt   (RE, gene, distance)
  ison_outputs_v2/{切片}/{切片}-ATAC.h5ad + {切片}-RNA.h5ad
用法：E:/miniconda/envs/ison_env/python.exe validate_distance_decay.py [切片]
"""
import os
import sys
import numpy as np
import pandas as pd
import scanpy as sc

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "ison_outputs_v2")
DIST = pd.read_csv(os.path.join(BASE, "linger_outputs", "RE_gene_distance.txt"), sep="\t")
SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]

BINS = [(0, 5000, "<5kb"), (5000, 10000, "5-10kb"), (10000, 50000, "10-50kb"),
        (50000, 100000, "50-100kb"), (100000, 200000, "100-200kb"), (200000, 1000000, "200kb-1Mb")]

def bin_of(d):
    for lo, hi, name in BINS:
        if lo <= d < hi:
            return name
    return None

DIST["bin"] = DIST["distance"].apply(bin_of)
DIST = DIST[DIST["bin"].notna()]

def corr_slice(s):
    atac = sc.read_h5ad(os.path.join(OUT, s, f"{s}-ATAC.h5ad"))
    rna = sc.read_h5ad(os.path.join(OUT, s, f"{s}-RNA.h5ad"))
    Xa = np.asarray(atac.X)
    Xr = np.asarray(rna.X)
    peak_idx = {p: i for i, p in enumerate(atac.var_names)}
    gene_idx = {g: i for i, g in enumerate(rna.var_names)}
    # 每个 bin 采样最多 300 对，算相关系数
    results = {}
    for bin_name in [b[2] for b in BINS]:
        sub = DIST[DIST["bin"] == bin_name]
        cors = []
        for _, row in sub.sample(min(300, len(sub)), random_state=42).iterrows():
            if row["RE"] not in peak_idx or row["gene"] not in gene_idx:
                continue
            a = Xa[:, peak_idx[row["RE"]]]
            g = Xr[:, gene_idx[row["gene"]]]
            if np.std(a) < 1e-9 or np.std(g) < 1e-9:
                continue
            cors.append(np.corrcoef(a, g)[0, 1])
        results[bin_name] = (len(cors), np.median(cors) if cors else np.nan)
    return results

if __name__ == "__main__":
    targets = sys.argv[1:] or SLICES
    all_results = {b[2]: [] for b in BINS}
    save_rows = []
    for s in targets:
        p = os.path.join(OUT, s, f"{s}-ATAC.h5ad")
        if not os.path.exists(p):
            continue
        r = corr_slice(s)
        print(f"=== {s} ===")
        for bin_name, (n, med) in r.items():
            all_results[bin_name].append(med)
            save_rows.append({"slice": s, "bin": bin_name, "n_pairs": n, "median_pcc": med})
            print(f"  {bin_name:12s} n={n:4d} 中位PCC={med:.4f}")
    print("\n=== 汇总（跨切片中位）===")
    for bin_name in [b[2] for b in BINS]:
        vals = [v for v in all_results[bin_name] if not np.isnan(v)]
        if vals:
            print(f"  {bin_name:12s} 中位PCC={np.median(vals):.4f}")
    pd.DataFrame(save_rows).to_csv(
        os.path.join(BASE, "linger_outputs", "distance_decay_results.tsv"),
        sep="\t", index=None)
    print("[SAVED] linger_outputs/distance_decay_results.tsv")
