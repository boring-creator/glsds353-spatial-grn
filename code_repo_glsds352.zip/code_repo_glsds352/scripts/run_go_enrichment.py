# -*- coding: utf-8 -*-
"""run_go_enrichment.py — 图三：显著 GRN 模块的 GO 富集气泡图（原始版本）
论文方法（ison论文.md Methods）: gseapy.enrichr + GO_Biological_Process_2025，combined score
输入: gene_modules.txt, GSEA_NES_celltype_module.txt
输出: linger_outputs/GO_enrichment_modules.tsv, figures/Fig3_GO_modules.png
用法: E:/miniconda/envs/ison_env/python.exe run_go_enrichment.py
"""
import os
import time
import numpy as np
import pandas as pd
import gseapy as gp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
FIG  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(FIG, exist_ok=True)

TSV = os.path.join(BASE, "GO_enrichment_modules.tsv")

# ================= 1. 富集（已有结果则跳过）=================
if not os.path.exists(TSV):
    modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
    gsea = pd.read_csv(os.path.join(BASE, "GSEA_NES_celltype_module.txt"), sep="\t")
    sig_mods = sorted(gsea[gsea.FWER_p < 0.05].module.str.replace("M", "").astype(int).unique())
    print("显著模块:", [f"M{m}" for m in sig_mods])
    module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in sig_mods}
    print("各显著模块基因数:", {k: len(v) for k, v in module_sets.items()})
    all_rows = []
    for name, genes in module_sets.items():
        for attempt in range(4):
            try:
                res = gp.enrichr(gene_list=genes, gene_sets="GO_Biological_Process_2025",
                                 organism="mouse").results
                res["module"] = name
                res = res[["module", "Term", "Overlap", "P-value", "Adjusted P-value",
                           "Odds Ratio", "Combined Score", "Genes"]]
                all_rows.append(res)
                print(f"[{name}] {len(res)} terms", flush=True)
                break
            except Exception as e:
                print(f"[{name}] retry: {e}", flush=True)
                time.sleep(5)
    out = pd.concat(all_rows, ignore_index=True)
    out.to_csv(TSV, sep="\t", index=None)
    print(f"[DONE] GO enrichment: {out.shape}")
else:
    out = pd.read_csv(TSV, sep="\t")
    print(f"复用 GO_enrichment_modules.tsv ({out.shape})")

# ================= 2. 气泡图（原始版本）=================
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def short_term(term):
    return term.split(" (GO:")[0]

def wrap_term(s, width=42):
    words, lines, cur = s.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur); cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return "\n".join(lines)

def top_terms(rows, module, top_n=8, min_n=2):
    d = rows[rows.module == module].copy()
    sig = d[d["Adjusted P-value"] < 0.05]
    if len(sig) > 0:
        d = sig
    if len(d[d.Overlap.str.split("/").str[0].astype(int) >= min_n]) >= 2:
        d = d[d.Overlap.str.split("/").str[0].astype(int) >= min_n]
    d = d.copy()
    d["gc"] = d.Overlap.str.split("/").str[0].astype(int)
    d["nlogP"] = -np.log10(d["Adjusted P-value"].clip(lower=1e-300))
    d["Term"] = d.Term.map(short_term).map(wrap_term)
    d = d.sort_values(["nlogP", "Combined Score"], ascending=[True, True]).tail(top_n)
    return d

out["_gc"] = out.Overlap.str.split("/").str[0].astype(int)
# 主图 4 模块（M11/M5/M8 突触-可塑性 + M3 翻译）；M2/M9/M6 进补充图
modules_show = [m for m in ["M11", "M5", "M8", "M3"] if m in out.module.values]
n = len(modules_show)
cols = 2
rows = 2
fig, axes = plt.subplots(rows, cols, figsize=(8.5 * cols, 6.2 * rows))
axes = np.array(axes).flatten()

sc = None
for i, m in enumerate(modules_show):
    d = top_terms(out, m)
    ax = axes[i]
    ax.scatter(d.nlogP, d.Term, s=60 + 9 * d.gc,
               c=d["Combined Score"], cmap="YlOrRd", edgecolors="black",
               linewidths=0.5, alpha=0.9, vmin=0)
    ax.set_title(m, fontsize=13, fontweight="bold")
    ax.set_xlabel("-log10(adjP)", fontsize=10)
    ax.tick_params(axis="y", labelsize=8)
    ax.tick_params(axis="x", labelsize=9)
    for label in ax.get_yticklabels():
        label.set_ha("right")
    sc = ax.collections[0]

for j in range(i + 1, len(axes)):
    axes[j].axis("off")

if sc is not None:
    cbar = fig.colorbar(sc, ax=axes[:n], shrink=0.5, pad=0.015, fraction=0.03)
    cbar.set_label("Enrichr Combined Score", fontsize=11)

handles = [Line2D([0], [0], marker="o", color="w", markerfacecolor="grey",
                  markersize=np.sqrt((60 + 9 * c) / np.pi) * 0.45, label=str(c))
           for c in (5, 15, 30, 60)]
fig.legend(handles=handles, title="Overlap gene count", loc="upper right",
           frameon=False, bbox_to_anchor=(0.995, 0.97))
fig.suptitle("GO Biological Process 2025 — GRN modules (Enrichr)\n"
             "Synaptic & plasticity modules (M11/M5/M8) and translation (M3); "
             "each panel uses independent x-axis scales",
             fontsize=13.5, fontweight="bold", y=0.99)
plt.tight_layout(rect=[0, 0, 0.88, 0.96])
fig.savefig(os.path.join(FIG, "Fig3_GO_modules.png"), dpi=300, bbox_inches="tight")
print("[DONE] 气泡图:", os.path.join(FIG, "Fig3_GO_modules.png"))

# ================= 补充图：M2/M9/M6（弱/重叠/与海马叙事脱节）=================
supp_mods = [m for m in ["M2", "M9", "M6"] if m in out.module.values]
if len(supp_mods):
    n2 = len(supp_mods)
    fig2, axes2 = plt.subplots(1, n2, figsize=(7.5 * n2, 5.8))
    axes2 = np.array([axes2]).flatten()
    sc2 = None
    for i, m in enumerate(supp_mods):
        d = top_terms(out, m)
        ax = axes2[i]
        ax.scatter(d.nlogP, d.Term, s=60 + 9 * d.gc, c=d["Combined Score"],
                   cmap="YlOrRd", edgecolors="black", linewidths=0.5, alpha=0.9, vmin=0)
        ax.set_title(m, fontsize=13, fontweight="bold")
        ax.set_xlabel("-log10(adjP)", fontsize=10)
        ax.tick_params(axis="y", labelsize=8); ax.tick_params(axis="x", labelsize=9)
        for label in ax.get_yticklabels():
            label.set_ha("right")
        if sc2 is None:
            sc2 = ax.collections[0]
    for j in range(i + 1, len(axes2)):
        axes2[j].axis("off")
    fig2.colorbar(sc2, ax=axes2[:n2], shrink=0.5, pad=0.015, fraction=0.04)\
        .set_label("Enrichr Combined Score", fontsize=11)
    fig2.suptitle("Supplementary: GO enrichment of additional modules (M2/M9/M6; "
                  "independent x-axis scales)", fontsize=13, fontweight="bold", y=0.98)
    plt.tight_layout(rect=[0, 0, 0.9, 0.95])
    fig2.savefig(os.path.join(FIG, "FigS_GO_modules_supp.png"), dpi=300, bbox_inches="tight")
    print("[DONE] 补充图: FigS_GO_modules_supp.png")
