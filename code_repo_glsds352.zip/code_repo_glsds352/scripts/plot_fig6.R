#!/usr/bin/env Rscript
# plot_fig6.R — 图五（机制图）：太空飞行 → 应激 TF 活性 → 模块因果 → 空间亚区
#   A. 应激 TF 活性 FL vs GC（159 批次内部对照，批次匹配，方向性）
#   B. 关键 TF 靶基因 vs 模块富集（clusterProfiler::enricher）
#   C. 关键基因空间亚区定位（159 批次 FL vs GC）
suppressMessages({library(ggplot2); library(dplyr); library(patchwork)})

base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
L <- file.path(base, "linger_outputs")
FL159 <- c("159_C1", "159_D1"); GC159 <- c("159_A1", "159_B1")

# 细胞类型编号 → RR3 区域短名（与图四一致）
ct_names <- c("0"="0 SomMot/Vis", "1"="1 Hypo/Pit", "2"="2 Pirif/amyg",
              "4"="4 White matter", "5"="5 CA1 radiat", "6"="6 CA3",
              "7"="7 Thalamus", "8"="8 Hypo/Pit", "9"="9 MidGABA",
              "11"="11 Pirif/amyg", "15"="15 CA3", "17"="17 White matter")

# ============ Panel A: 159 批次内部对照 TF 活性方向热图 ============
tf <- read.delim(file.path(L, "TF_activity.txt"), row.names = 1, check.names = FALSE)
grp <- data.frame(group = colnames(tf))
grp$slice <- sub("_[0-9]+$", "", colnames(tf)); grp$ct <- sub("^.*_", "", colnames(tf))
g159 <- grp[grp$slice %in% c(FL159, GC159), ]
g159$cond <- ifelse(g159$slice %in% FL159, "FL", "GC")
stress_tfs <- c("Nr3c1", "Junb", "Jun", "Jund", "Fosl2", "Nr4a2", "Egr3",
                "Nr4a1", "Egr1", "Fos")
cts <- sort(unique(as.integer(g159$ct)))
mat <- sapply(stress_tfs, function(tfn) sapply(cts, function(cti) {
  fl <- as.numeric(tf[tfn, g159$group[g159$ct == as.character(cti) & g159$cond == "FL"]])
  gc <- as.numeric(tf[tfn, g159$group[g159$ct == as.character(cti) & g159$cond == "GC"]])
  if (length(fl) && length(gc)) mean(fl) - mean(gc) else NA
}))
rownames(mat) <- ct_names[as.character(cts)]
hmat <- reshape2::melt(mat); colnames(hmat) <- c("ct", "TF", "d")
hmat$ct <- factor(hmat$ct, levels = ct_names[as.character(cts)])
hmat$TF <- factor(hmat$TF, levels = rev(stress_tfs))

pA <- ggplot(hmat, aes(ct, TF, fill = d)) +
  geom_tile(color = "white", linewidth = 0.6) +
  geom_text(aes(label = ifelse(is.na(d), "", sprintf("%+.2f", d))), size = 3) +
  scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b",
                       midpoint = 0, na.value = "grey90", name = "FL-GC\nTF activity") +
  labs(x = NULL, y = NULL,
       title = "A | Stress-axis TF activity (batch-159 control, FL vs GC)") +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(size = 7.5, angle = 45, hjust = 1),
        axis.text.y = element_text(size = 9, face = "italic"),
        plot.title = element_text(face = "bold", hjust = 0, size = 11))

# ============ Panel B: TF×模块点阵图（全部 10 个应激 TF，消除 cherry-pick）============
suppressMessages(library(clusterProfiler))
trans <- read.delim(file.path(L, "trans_regulatory.txt"), row.names = 1, check.names = FALSE)
mods  <- read.delim(file.path(L, "gene_modules.txt"))
TERM2GENE <- data.frame(term = paste0("M", mods$module), gene = mods$gene)
ALL_TF <- c("Nr3c1", "Junb", "Jun", "Jund", "Fosl2", "Nr4a2", "Egr3", "Nr4a1", "Egr1", "Fos")
MODS_B <- c("M2", "M3", "M5", "M6", "M8", "M9", "M11")
enr_rows <- list()
for (tfv in ALL_TF) {
  s <- trans[[tfv]]; names(s) <- rownames(trans)
  top <- names(sort(s, decreasing = TRUE)[1:200])
  e <- tryCatch(enricher(top, TERM2GENE = TERM2GENE, pAdjustMethod = "BH",
                         minGSSize = 3, maxGSSize = 2000), error = function(err) NULL)
  if (!is.null(e) && nrow(as.data.frame(e)) > 0) {
    r <- as.data.frame(e); r$TF <- tfv
    enr_rows[[tfv]] <- r[, c("TF", "ID", "p.adjust")]
  }
}
enr <- do.call(rbind, enr_rows)
enr$nlogP <- -log10(pmax(enr$p.adjust, 1e-300))
Bmat <- data.frame(TF = ALL_TF)
for (m in MODS_B) {
  Bmat[[m]] <- sapply(ALL_TF, function(tf) {
    hit <- enr[enr$TF == tf & enr$ID == m, ]
    if (nrow(hit)) max(hit$nlogP) else NA
  })
}
bdat <- reshape2::melt(Bmat, id.vars = "TF", variable.name = "module", value.name = "nlogP")
bdat$module <- factor(bdat$module, levels = MODS_B)
bdat$TF <- factor(bdat$TF, levels = rev(ALL_TF))

pB <- ggplot(bdat, aes(module, TF)) +
  geom_point(aes(size = nlogP, color = nlogP), na.rm = TRUE, alpha = 0.85) +
  scale_size_continuous(range = c(2, 10), name = "-log10(adjP)") +
  scale_color_gradient(low = "grey85", high = "#d7301f", name = "-log10(adjP)",
                       guide = guide_legend(override.aes = list(size = 5))) +
  labs(x = "GRN module", y = NULL,
       title = "B | TF target gene sets enriched in modules (all 10 stress-axis TFs)") +
  theme_minimal(base_size = 10.5) +
  theme(axis.text.y = element_text(face = "italic", size = 9),
        axis.text.x = element_text(size = 9),
        plot.title = element_text(face = "bold", hjust = 0))

# ============ Panel C: 关键基因空间亚区定位（159 批次 FL vs GC）============
md <- read.csv(file.path(base, "marker_159_data.csv"))
sa <- read.delim(file.path(L, "spot_annotation.tsv"))
sa$spot <- sa$barcode; sa$slice <- sa$section
m <- merge(md, sa[, c("spot", "slice", "annot_rr3")], by = c("slice", "spot"), all.x = TRUE)
m$num <- as.integer(sub("^(\\d+).*", "\\1", m$annot_rr3))
m$region <- ifelse(m$num == 6, "CA1 pyr", ifelse(m$num == 8, "CA3",
              ifelse(m$num == 10, "CA1 radiat", ifelse(m$num == 11, "DG", "Other"))))
m$cond <- ifelse(m$slice %in% FL159, "FL", "GC")
m <- m[!is.na(m$region) & m$region != "Other" & !is.na(m$marker), ]
pC_data <- m[m$marker %in% c("Egr1", "Nr3c1", "Nrgn"), ]
pC_data$region <- factor(pC_data$region, levels = c("DG", "CA1 radiat", "CA1 pyr", "CA3"))
pC_data$marker <- factor(pC_data$marker, levels = c("Egr1", "Nr3c1", "Nrgn"))
pC <- ggplot(pC_data, aes(region, expr, fill = cond)) +
  geom_violin(position = position_dodge(0.8), width = 0.8, alpha = 0.6, scale = "width") +
  geom_boxplot(width = 0.15, outlier.shape = NA, fill = "white",
               position = position_dodge(0.8)) +
  facet_wrap(~marker, nrow = 1, scales = "free_y") +
  scale_fill_manual(values = c("FL" = "#b2182b", "GC" = "#4393c3"), name = NULL) +
  labs(x = NULL, y = "Expression per spot",
       title = "C | Key genes by hippocampal subregion (batch 159; descriptive, n = 1 animal/condition)") +
  theme_minimal(base_size = 10.5) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
        legend.position = "top", plot.title = element_text(face = "bold", hjust = 0))

# ============ 拼版 + 完整 caption ============
fig <- (pA | pC) / pB + plot_layout(heights = c(1, 1.1)) +
  plot_annotation(
    title = "Figure 5 | Mechanism: stress-axis TF activity rewires hippocampal modules",
    subtitle = paste0("A | Activity of stress-axis transcription factors (glucocorticoid receptor Nr3c1; ",
                      "AP-1 Jun/Junb; immediate-early Egr1/Fos) in the batch-159 internal control ",
                      "(FL = F1 vs GC = G7), shown as FL-GC activity per cell type (region-annotated). ",
                      "B | Target genes of key TFs (top 200 by trans-network weight) are enriched in ",
                      "flight-altered modules (clusterProfiler enricher, BH-adjusted P). ",
                      "C | Expression of Egr1, Nr3c1 and Nrgn by hippocampal subregion in batch 159 (FL vs GC)."),
    theme = theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"),
                  plot.subtitle = element_text(hjust = 0.5, size = 8.5, color = "grey25")))
ggsave(file.path(outdir, "Fig5_mechanism.png"), fig, width = 16, height = 11.5,
       dpi = 300, limitsize = FALSE)
ggsave(file.path(outdir, "Fig5_mechanism.tiff"), fig, width = 16, height = 11.5,
       dpi = 300, limitsize = FALSE, device = "tiff")
cat("\n[DONE] Fig5_mechanism.png + .tiff (300 dpi)\n")
