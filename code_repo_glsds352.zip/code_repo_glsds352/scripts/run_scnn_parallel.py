# -*- coding: utf-8 -*-
"""run_scnn_parallel.py — LINGER scNN 训练并行驱动（论文环境 scnn_paper）。

复用 LINGER 源码的 sc_nn_NN（不改算法），仅将 training() 的串行循环改为
multiprocessing 并行（fork 继承数据，COW）。输出格式与 training() 完全一致：
  每染色体 {chr}_net.pt / {chr}_shap.pt / {chr}_Loss.txt + RE_TGlink.txt

用法（scnn_paper env，cwd=/root/autodl-tmp/linger）：
  nohup python run_scnn_parallel.py > scnn_parallel.log 2>&1 &
"""
import os
import time
import numpy as np
import pandas as pd
import torch
import multiprocessing as mp

import LingerGRN.LINGER_tr as LT

GRNdir = "/root/autodl-tmp/scnn/provide_data/"
outdir = "/root/autodl-tmp/linger/grn_out/"
N_JOBS = 64
L1 = 0.01
ACTIVE = "ReLU"

os.makedirs(outdir, exist_ok=True)

print("[1] 加载数据 ...", flush=True)
Exp, Opn, Target, RE_TGlink = LT.load_data_scNN(GRNdir, "New")
# 染色体（与 training() 一致：取每个基因第一个 RE 的染色体）
chrall = [RE_TGlink[0].iloc[i][0].split(":")[0] for i in range(RE_TGlink.shape[0])]
RE_TGlink["chr"] = chrall
chrlist = RE_TGlink["chr"].unique()
print(f"    模型数 {RE_TGlink.shape[0]}，染色体 {len(chrlist)} 个", flush=True)


def _init(E, O, T, l1, af):
    global Exp_g, Opn_g, Target_g, l1_g, af_g
    Exp_g, Opn_g, Target_g, l1_g, af_g = E, O, T, l1, af
    torch.set_num_threads(1)


def _worker(i, row):
    return LT.sc_nn_NN(i, row, Target_g, Exp_g, Opn_g, l1_g, af_g)


t0 = time.time()
for chrtemp in chrlist:
    RE_TGlink1 = RE_TGlink[RE_TGlink["chr"] == chrtemp]
    rows = RE_TGlink1.values
    n = rows.shape[0]
    with mp.Pool(N_JOBS, initializer=_init,
                 initargs=(Exp, Opn, Target, L1, ACTIVE)) as pool:
        results = pool.starmap(_worker, [(i, rows[i]) for i in range(n)])
    netall_s = {i: r[0] for i, r in enumerate(results)}
    shapall_s = {i: r[1] for i, r in enumerate(results)}
    Lossall = np.vstack([np.asarray(r[2]).flatten() for r in results])
    torch.save(netall_s, outdir + chrtemp + "_net.pt")
    torch.save(shapall_s, outdir + chrtemp + "_shap.pt")
    Lossall = pd.DataFrame(Lossall)
    Lossall.index = RE_TGlink1["gene"].values
    Lossall.to_csv(outdir + chrtemp + "_Loss.txt", sep="\t")
    print(f"  [{chrtemp}] {n} 基因完成，累计 {(time.time()-t0)/60:.1f} min", flush=True)

RE_TGlink.to_csv(outdir + "RE_TGlink.txt", sep="\t", index=None)
print(f"[DONE] scNN 并行训练完成，总耗时 {(time.time()-t0)/60:.1f} min", flush=True)
