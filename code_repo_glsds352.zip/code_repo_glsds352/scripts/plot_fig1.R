#!/usr/bin/env Rscript
# plot_fig1.R — 图一 v4：H&E 叠加（标准 spaceranger 映射）
#   数据：tissue_hires_image.png + scalefactors_json.json + pxl×scalef（正确对齐）
#   FL 上排/GC 下排 / 海马 4 亚区彩色其余灰 / 500μm 比例尺 / 组成图
suppressMessages({library(ggplot2); library(dplyr); library(patchwork); library(png); library(grid)})
base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
L <- file.path(base, "linger_outputs")
HE <- "E:/space/data/visium_full/visium_data"

dat <- read.delim(file.path(L, "spot_hires_plot.tsv"))
scale <- read.csv(file.path(L, "hires_scale.csv"))

FL_slices <- c("158_A1","158_B1","158_C1","158_D1","159_C1","159_D1")
GC_slices <- c("159_A1","159_B1","304_A1","304_B1","304_C1","304_D1")
slice_order <- c(FL_slices, GC_slices)

dat$region <- factor(dat$region, levels = c("DG","CA1 pyr","CA1 radiat","CA3","Other"))
pal <- c("DG"="#ff7f00","CA1 pyr"="#e41a1c","CA1 radiat"="#984ea3","CA3"="#2388BB","Other"="grey45")
anim_map <- c("158_A1"="F2","158_B1"="F2","158_C1"="F7","158_D1"="F7",
              "159_C1"="F1","159_D1"="F1","159_A1"="G7","159_B1"="G7",
              "304_A1"="G9","304_B1"="G9","304_C1"="G8","304_D1"="G8")

panel_one <- function(s) {
  d <- dat[dat$section == s, ]
  img <- readPNG(file.path(HE, paste0("Sample_", s), "tissue_hires_image.png"))
  wd <- ncol(img); hd <- nrow(img)
  g <- rasterGrob(img, interpolate = TRUE)
  d$yp <- hd - d$y                       # 图像 y 翻转
  ttl <- paste0(ifelse(s %in% FL_slices, "FL", "GC"), " · ",
                anim_map[s], "·", sub(".*_", "", s))   # 动物 ID 标题
  p <- ggplot(d) +
    annotation_custom(g, xmin=0, xmax=wd, ymin=0, ymax=hd) +
    geom_point(aes(x, yp, color=region), size=0.9, alpha=0.3) +
    scale_color_manual(values=pal, name="Hippocampal subregion") +
    coord_fixed(xlim=c(0,wd), ylim=c(0,hd), expand=FALSE) +
    labs(title=ttl) +
    theme_void() +
    theme(plot.title=element_text(hjust=0.5, face="bold", size=10.5),
          plot.margin=margin(4,2,2,2), legend.position="none")
  p
}

# 比例尺：仅 158_A1（左上角），500μm = 141.4 hires px，对所有切片适用
d <- dat[dat$section == "158_A1", ]
img <- readPNG(file.path(HE, "Sample_158_A1", "tissue_hires_image.png"))
hd <- nrow(img); wd <- ncol(img)
bar <- 141.4
x0 <- 15; y0 <- hd - 40          # 左上角，往下挪避免被挡
p_sb <- panel_one("158_A1") +
  # 比例尺（左上，仅此面板）
  annotate("rect", xmin=x0-5, xmax=x0+bar+62, ymin=y0-7, ymax=y0+6,
           fill="white", alpha=0.75) +
  annotate("segment", x=x0, xend=x0+bar, y=y0, yend=y0, color="black", linewidth=1.2) +
  annotate("text", x=x0+bar+3, y=y0, label="500 μm", hjust=0, size=3.2, color="black")

plist <- lapply(slice_order, function(s) if (s == "158_A1") p_sb else panel_one(s))
pA <- wrap_plots(plist, ncol=6, nrow=2) + plot_layout(guides="collect") +
  theme(legend.position="right",
        legend.box.background=element_rect(fill="white", colour="black", linewidth=0.4),
        legend.key.size=unit(4, "mm"),
        legend.title=element_text(size=9), legend.text=element_text(size=8.5))

# 组成图：每动物均值（消除伪重复 n=12→n=6；每柱 = 2 张切片平均比例）
pal_hip <- c("DG"="#ff7f00","CA1 pyr"="#e41a1c","CA1 radiat"="#984ea3","CA3"="#2388BB")
hip <- dat[dat$region != "Other", ]
hip$animal <- anim_map[as.character(hip$section)]
comp_sec <- hip %>% group_by(section, region) %>% summarise(n=n(), .groups="drop") %>%
  group_by(section) %>% mutate(frac = n/sum(n))
comp_sec$animal <- anim_map[as.character(comp_sec$section)]
comp_anim <- comp_sec %>% group_by(animal, region) %>% summarise(frac=mean(frac), .groups="drop")
# 按玻片排序：159混合(F1,G7) | 158FL(F2,F7) | 304GC(G8,G9)
comp_anim$cond <- ifelse(comp_anim$animal %in% c("F1","F2","F7"), "FL", "GC")
anim_order <- c("F1","G7","F2","F7","G8","G9")
comp_anim$animal <- factor(comp_anim$animal, levels=anim_order)
xcol <- setNames(ifelse(grepl("^F", anim_order), "#b2182b", "#4393c3"), anim_order)  # FL红 GC蓝
pB <- ggplot(comp_anim, aes(animal, frac, fill=region)) +
  geom_col(position="stack", width=0.72) +
  scale_fill_manual(values=pal_hip, name="Hippocampal subregion", guide="none") +
  scale_y_continuous(labels=scales::percent) +
  geom_vline(xintercept=c(2.5, 4.5), linetype="dashed", color="grey40") +
  annotate("text", x=1.5, y=0.97, label="Slide 159 (mixed)", size=3.4, fontface="bold") +
  annotate("text", x=3.5, y=0.97, label="Slide 158 (FL)", size=3.4, fontface="bold") +
  annotate("text", x=5.5, y=0.97, label="Slide 304 (GC)", size=3.4, fontface="bold") +
  labs(x=NULL, y="Proportion (within hippocampus)",
       title="Hippocampal subregion composition (mean of 2 sections/animal; label color = FL/GC)") +
  theme_minimal(base_size=10) +
  theme(axis.text.x=element_text(angle=45, hjust=1, size=9, color=xcol, fontface="plain"),
        legend.position="none")

# 新面板：海马绝对 spot 数（证明组间无系统性差异）
hip_cnt <- hip %>% group_by(animal) %>% summarise(n=n(), .groups="drop")
hip_cnt$cond <- ifelse(hip_cnt$animal %in% c("F1","F2","F7"), "FL", "GC")
hip_cnt$animal <- factor(hip_cnt$animal, levels=c("F1","F2","F7","G7","G8","G9"))
pC <- ggplot(hip_cnt, aes(animal, n, fill=cond)) +
  geom_col(width=0.72) +
  scale_fill_manual(values=c("FL"="#b2182b","GC"="#4393c3"), name="Condition") +
  labs(x=NULL, y="Hippocampal spot count",
       title="Absolute hippocampus size (spots per animal)") +
  theme_minimal(base_size=10) +
  theme(axis.text.x=element_text(angle=45, hjust=1, size=9, fontface="plain"),
        legend.position="right", legend.key.size=unit(0.4,"cm"))

fig <- (pA / (pB | pC)) + plot_layout(heights=c(4, 1.35), widths=c(2.6, 1))
fig <- fig + plot_annotation(
  title="Figure 1 | Hippocampal Visium sections on H&E",
  subtitle=paste0("12 sections from 6 mice (3 flight FL, 3 ground GC); 2 consecutive hippocampal sections per animal. ",
                  "Spots colored by published region annotations; hippocampal subregions highlighted. ",
                  "Scale bar = 500 μm. Spaceranger-aligned tissue images."),
  theme=theme(plot.title=element_text(hjust=0.5, size=13, face="bold"),
              plot.subtitle=element_text(hjust=0.5, size=9, color="grey25")))
ggsave(file.path(outdir, "Fig1_spatial_overview.png"), fig,
       width=18, height=13, dpi=300, limitsize=FALSE)
cat("[DONE] figures/Fig1_spatial_overview.png\n")
