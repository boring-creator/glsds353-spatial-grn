# -*- coding: utf-8 -*-
"""make_graphical_abstract.py — 机制示意图 / Graphical abstract
太空飞行 → 海马 CA1-CA3 神经元 → GR/应激 TF 活性升高 → 下游突触-可塑性模块 mRNA 上调
顺时针 2×2 四框排列：1 左上 → 2 右上 → 3 右下 → 4 左下，箭头顺时针
画面内仅保留结论链条 + 一条趋势佐证；数据/统计层级信息移入图注（见 Graphical_abstract_caption.md）
用法: E:/miniconda/envs/valenv/python.exe make_graphical_abstract.py
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Helvetica", "Arial", "DejaVu Sans"]

fig, ax = plt.subplots(figsize=(17, 8))
ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

C1 = "#b2182b"   # 太空飞行（红）
C2 = "#377eb8"   # 海马（蓝）
C3 = "#e08214"   # GR/TF（橙）
C4 = "#4daf4a"   # 模块（绿）

def box(x, y, w, h, title, body, color):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02",
                       linewidth=2, edgecolor=color, facecolor="white", zorder=2)
    ax.add_patch(p)
    ax.text(x + w/2, y + h - 0.055, title, ha="center", va="center",
            fontsize=13, fontweight="bold", color=color, zorder=5)
    if body:
        ax.text(x + w/2, y + h*0.40, body, ha="center", va="center",
                fontsize=10.5, color="#222222", linespacing=1.5, zorder=5)

def arrow(x0, y0, x1, y1, color="#444444", lw=2.5):
    a = FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                        mutation_scale=26, linewidth=lw, color=color, zorder=3)
    ax.add_patch(a)

# 布局（2×2 顺时针；顶部两框留出 0.14 间距容纳箭头标签；整体上移留底部空白）
LX, LW = 0.07, 0.36        # 左列
RX, RW = 0.57, 0.36        # 右列
TY, TH = 0.60, 0.32        # 上排
BY, BH = 0.22, 0.32        # 下排
LXc = LX + LW/2            # 左列中心 x
RXc = RX + RW/2            # 右列中心 x
TYc = TY + TH/2            # 上排中心 y
BYc = BY + BH/2            # 下排中心 y

# 1) 太空飞行（左上）
box(LX, TY, LW, TH, "Spaceflight", "microgravity\n+ radiation\n(FL, n=3)", C1)

# 2) 海马神经元（右上，无装饰图标，保持简洁）
box(RX, TY, RW, TH, "Hippocampal neurons", "(CA1-CA3 pyramidal, DG)", C2)

# 3) GR/应激 TF（右下）
box(RX, BY, RW, BH, "GR / stress TF\nactivity \u2191",
    "Nr3c1 (GR) \u2191\nJun/Junb \u2191\nEgr1/Fos \u2193\n(partial IEG desensitization)", C3)

# 4) 突触模块 mRNA（左下）
box(LX, BY, LW, BH, "Synaptic-plasticity\nmodules mRNA \u2191",
    "M5 / M11 / M8\n(synapse, plasticity)\nUp-regulated in 8/10 hippocampal cell types", C4)

# 顺时针箭头 1→2→3→4（缩短）
arrow(LX + LW, TYc, RX, TYc)     # 上：1 → 2
arrow(RXc, TY, RXc, BY + BH)     # 右：2 → 3
arrow(RX, BYc, LX + LW, BYc)     # 下：3 → 4

# 上箭头标签（白底衬在箭头线上，永不压框）
ax.text(0.50, TYc, "stress stimulus", ha="center", va="center", fontsize=9.5,
        color="#444444", style="italic", zorder=6,
        bbox=dict(facecolor="white", edgecolor="none", pad=2))

# 画面内唯一底部说明（趋势佐证，不写 validate）
ax.text(0.5, 0.11,
        "Within-batch consistency (batch 159): 87.3% direction agreement, supporting the trend in aggregated multi-animal analysis",
        ha="center", fontsize=11, color="#555555")

fig.savefig("figures/Graphical_abstract.png", dpi=300, bbox_inches="tight")
fig.savefig("figures/Graphical_abstract.tiff", dpi=300, bbox_inches="tight")
print("[DONE] figures/Graphical_abstract.png/.tiff")
