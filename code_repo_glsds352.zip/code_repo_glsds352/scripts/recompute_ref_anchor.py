# -*- coding: utf-8 -*-
"""recompute_ref_anchor.py — 参考锚定：逐 spot PCC(预测ATAC, 期望ATAC)（图二强验证）
输入: ison_outputs_v2/{s}/{s}-ATAC.h5ad（预测）+ ison_outputs_v2/npz/{s}_exp_atac.npy（期望）
输出: linger_outputs/ref_anchor_results.tsv (slice, spot_idx, pcc)
用法: E:/miniconda/envs/valenv/python.exe recompute_ref_anchor.py
"""
import os
import numpy as np
import pandas as pd
import scanpy as sc

BASE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(BASE, "ison_outputs_v2")
NPZ  = os.path.join(OUT, "npz")
SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]

def per_spot_pcc(Xa, Xe):
    """逐 spot: corrcoef(预测, 期望)，跨全部 peak"""
    n = Xa.shape[0]
    cors = np.empty(n)
    for i in range(n):
        a = Xa[i]; e = Xe[i]
        if np.std(a) < 1e-9 or np.std(e) < 1e-9:
            cors[i] = np.nan
        else:
            cors[i] = np.corrcoef(a, e)[0, 1]
    return cors

rows = []
for s in SLICES:
    fp = os.path.join(OUT, s, f"{s}-ATAC.h5ad")
    fe = os.path.join(NPZ, f"{s}_exp_atac.npy")
    if not (os.path.exists(fp) and os.path.exists(fe)):
        print(f"[SKIP] {s}"); continue
    ad = sc.read_h5ad(fp)
    Xa = ad.X.toarray() if hasattr(ad.X, "toarray") else np.asarray(ad.X)
    Xe = np.load(fe)
    if Xe.shape[0] != Xa.shape[0]:
        Xe = Xe.T
    cors = per_spot_pcc(Xa, Xe)
    print(f"  {s}: n={len(cors)} mean={np.nanmean(cors):.3f} median={np.nanmedian(cors):.3f}", flush=True)
    for i, c in enumerate(cors):
        rows.append({"slice": s, "spot_idx": i, "pcc": c})

pd.DataFrame(rows).to_csv(os.path.join(BASE, "linger_outputs", "ref_anchor_results.tsv"),
                          sep="\t", index=None)
print("[DONE] linger_outputs/ref_anchor_results.tsv", len(rows))
