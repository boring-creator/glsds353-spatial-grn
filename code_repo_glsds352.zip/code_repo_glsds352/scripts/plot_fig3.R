#!/usr/bin/env Rscript
# plot_fig3.R — 图三：GO 富集气泡图（R ggplot2，现成包）
#   数据：run_go_enrichment.py 的 gseapy Enrichr GO_Biological_Process_2025 结果
#   布局：上排 突触-可塑性 M11/M5/M8，下排 翻译-代谢 M3/M9/M2
suppressMessages({library(ggplot2); library(dplyr); library(patchwork); library(scales)})
base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
L <- file.path(base, "linger_outputs")

go <- read.delim(file.path(L, "GO_enrichment_modules.tsv"))
go$gc <- as.integer(sub("/.*", "", go$Overlap))
go$nlogP <- -log10(pmax(go$Adjusted.P.value, 1e-300))
go$Term <- sub(" \\(GO:.*", "", go$Term)   # 去 GO ID

THEMES <- list("Synaptic & plasticity modules" = c("M11", "M5", "M8"),
               "Translation & metabolism modules" = c("M3", "M9", "M2"))

# 每模块 top 5 显著术语（n>=2，按 adjP）
top_terms <- function(m) {
  d <- go[go$module == m, ]
  d <- d[d$Adjusted.P.value < 0.05, ]
  if (nrow(d[d$gc >= 2, ]) >= 2) d <- d[d$gc >= 2, ]
  d <- d[order(-d$nlogP), ]
  d$Term <- factor(d$Term, levels = rev(unique(d$Term[order(-d$nlogP)])))
  head(d, 5)
}

panels <- list()
for (theme in names(THEMES)) {
  for (m in THEMES[[theme]]) {
    d <- top_terms(m)
    p <- ggplot(d, aes(nlogP, Term)) +
      geom_point(aes(size = gc, color = `Combined.Score`), alpha = 0.85) +
      scale_size_continuous(range = c(3, 9), name = "Overlap\ngene count") +
      scale_color_gradient(low = "#fff7bc", high = "#d7301f", name = "Combined Score\n(z×−log10 P)") +
      labs(x = "-log10(adjP)", y = NULL, title = m) +
      theme_minimal(base_size = 10) +
      theme(axis.text.y = element_text(size = 7.5),
            axis.text.x = element_text(size = 8),
            plot.title = element_text(face = "bold", hjust = 0.5, size = 12),
            panel.grid.minor = element_blank(),
            legend.key.size = unit(0.3, "cm"), legend.text = element_text(size = 7))
    panels[[m]] <- p
  }
}

# 上排 + 下排（每排 3 面板），collect 统一图例
row1 <- wrap_plots(panels[c("M11", "M5", "M8")], ncol = 3)
row2 <- wrap_plots(panels[c("M3", "M9", "M2")], ncol = 3)
fig <- (row1 / row2) + plot_layout(heights = c(1, 1), guides = "collect") +
  theme(legend.position = "right",
        legend.box.background = element_rect(fill = "white", colour = "black", linewidth = 0.4),
        legend.key.size = unit(0.35, "cm"),
        legend.spacing.y = unit(0.9, "cm"),
        legend.margin = margin(6, 6, 6, 6))

fig <- fig + plot_annotation(
  title = "GO Biological Process 2025 enrichment of GRN modules (Enrichr)",
  subtitle = paste0("Top row: synaptic & plasticity modules (M11/M5/M8). ",
                    "Bottom row: translation & metabolism modules (M3/M9/M2). ",
                    "Bubble size = overlap gene count; color = Enrichr combined score. ",
                    "K-means assigns each gene to one module (gene overlap = 0)."),
  theme = theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"),
                plot.subtitle = element_text(hjust = 0.5, size = 9, color = "grey25")))

ggsave(file.path(outdir, "Fig3_GO_modules.png"), fig,
       width = 15, height = 9, dpi = 300, limitsize = FALSE)
cat("[DONE] figures/Fig3_GO_modules.png\n")
