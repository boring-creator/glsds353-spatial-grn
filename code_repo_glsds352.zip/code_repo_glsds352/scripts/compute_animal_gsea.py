# -*- coding: utf-8 -*-
"""compute_animal_gsea.py — 动物级 FL vs GC GSEA（消除切片级伪重复）
每个动物取其 2 张切片的细胞类型伪 bulk 均值 → 3 FL 动物 vs 3 GC 动物 → logFC → prerank
输入: linger_outputs/TG_pseudobulk.tsv, gene_modules.txt
输出: linger_outputs/logFC_FLvsGC_animal.txt, GSEA_NES_animal.txt
用法: E:/miniconda/envs/valenv/python.exe compute_animal_gsea.py
"""
import os
import numpy as np
import pandas as pd
import gseapy as gp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
ANIMAL = {"158_A1":"F2","158_B1":"F2","158_C1":"F7","158_D1":"F7",
          "159_C1":"F1","159_D1":"F1","159_A1":"G7","159_B1":"G7",
          "304_A1":"G9","304_B1":"G9","304_C1":"G8","304_D1":"G8"}
FL = {"F1", "F2", "F7"}

TG = pd.read_csv(os.path.join(BASE, "TG_pseudobulk.tsv"), sep=",", index_col=0)
# 列名 → (animal, ct)
gdf = pd.DataFrame({"group": TG.columns})
gdf["slice"] = gdf.group.str.rsplit("_", n=1).str[0]
gdf["ct"] = gdf.group.str.rsplit("_", n=1).str[1]
gdf["animal"] = gdf.slice.map(ANIMAL)
gdf["key"] = gdf.animal + "_" + gdf.ct
# 动物 × 细胞类型 伪 bulk：转置后按 (animal,ct) 均值
anim_tg = TG.T.groupby(gdf["key"].values).mean().T      # 基因 × (animal_ct)
cols = anim_tg.columns

cts = sorted(set(c.rsplit("_", 1)[1] for c in cols if c.rsplit("_", 1)[1] != "ct"))
logFC = pd.DataFrame(index=anim_tg.index)
for ct in cts:
    fl = [c for c in cols if c.rsplit("_", 1)[1] == ct and c.rsplit("_", 1)[0] in FL]
    gc = [c for c in cols if c.rsplit("_", 1)[1] == ct and c.rsplit("_", 1)[0] not in FL]
    if len(fl) and len(gc):
        logFC[ct] = np.log2((anim_tg[fl].mean(axis=1) + 1) / (anim_tg[gc].mean(axis=1) + 1))
logFC.to_csv(os.path.join(BASE, "logFC_FLvsGC_animal.txt"), sep="\t")
print("动物级 logFC:", logFC.shape, "| 细胞类型:", list(logFC.columns))

# prerank GSEA
modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}
rows = []
for ct in logFC.columns:
    r = logFC[ct].dropna()
    if len(r) < 10:
        continue
    pre = gp.prerank(rnk=r.sort_values(ascending=False), gene_sets=module_sets,
                     min_size=3, max_size=2000, permutation_num=1000, seed=42,
                     no_plot=True, outdir=None)
    for _, row in pre.res2d.iterrows():
        rows.append({"celltype": ct, "module": row["Term"],
                     "NES": row["NES"], "FWER_p": row["FWER p-val"]})
    nsig = (pre.res2d["FWER p-val"] < 0.05).sum()
    print(f"  [ct {ct}] 动物级 GSEA 完成, 显著 {nsig}", flush=True)
nes = pd.DataFrame(rows)
nes.to_csv(os.path.join(BASE, "GSEA_NES_animal.txt"), sep="\t", index=None)
print("[DONE] 动物级 GSEA:", nes.shape, "| 显著:", (nes.FWER_p < 0.05).sum())
