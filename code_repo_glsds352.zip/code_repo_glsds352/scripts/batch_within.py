# -*- coding: utf-8 -*-
"""batch_within.py — batch 内部对照（审稿#2建议）
比较 batch 158 内部 (F2 vs F7, 同 FL) 和 batch 304 内部 (G8 vs G9, 同 GC) 的模块差异。
若同 batch 内差异远小于跨 batch 差异，提示 batch effect 贡献。
输出: linger_outputs/batch_within_comparison.tsv
"""
import os, numpy as np, pandas as pd, gseapy as gp
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
ANIMAL = {"158_A1":"F2","158_B1":"F2","158_C1":"F7","158_D1":"F7",
          "159_C1":"F1","159_D1":"F1","159_A1":"G7","159_B1":"G7",
          "304_A1":"G9","304_B1":"G9","304_C1":"G8","304_D1":"G8"}
TG = pd.read_csv(os.path.join(BASE, "TG_pseudobulk.tsv"), sep=",", index_col=0)
gdf = pd.DataFrame({"group": TG.columns})
gdf["slice"] = gdf.group.str.rsplit("_", n=1).str[0]
gdf["ct"] = gdf.group.str.rsplit("_", n=1).str[1]
gdf["animal"] = gdf.slice.map(ANIMAL)
modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}

def run_pair(animal_a, animal_b, label):
    """两个动物间的模块 GSEA（同 batch 或跨 batch）"""
    rows = []
    for ct in sorted(gdf.ct.unique()):
        a = [c for c in TG.columns if gdf.set_index('group').loc[c,'animal']==animal_a and gdf.set_index('group').loc[c,'ct']==ct]
        b = [c for c in TG.columns if gdf.set_index('group').loc[c,'animal']==animal_b and gdf.set_index('group').loc[c,'ct']==ct]
        if not a or not b: continue
        lfc = np.log2((TG[a].mean(axis=1)+1)/(TG[b].mean(axis=1)+1)).dropna()
        if len(lfc) < 10: continue
        pre = gp.prerank(rnk=lfc.sort_values(ascending=False), gene_sets=module_sets,
                         min_size=3, max_size=2000, permutation_num=1000, seed=42, no_plot=True, outdir=None)
        for _, r in pre.res2d.iterrows():
            rows.append({"comparison": label, "celltype": ct, "module": r["Term"], "NES": r["NES"], "FWER_p": r["FWER p-val"]})
    return pd.DataFrame(rows)

# batch 158 内部: F2 vs F7 (同 FL) — 应接近 0（无真实差异）
b158 = run_pair("F2", "F7", "158_within_F2vsF7")
# batch 304 内部: G8 vs G9 (同 GC) — 应接近 0
b304 = run_pair("G8", "G9", "304_within_G8vsG9")
all_res = pd.concat([b158, b304])
all_res.to_csv(os.path.join(BASE, "batch_within_comparison.tsv"), sep="\t", index=None)
for lab, df in [("158内 F2vsF7", b158), ("304内 G8vsG9", b304)]:
    if len(df):
        print(f"{lab}: {len(df)} 组合, |NES|max={abs(df.NES).max():.2f}, 显著(FWER<0.05): {(df.FWER_p<0.05).sum()}")
    else:
        print(f"{lab}: 无数据")
# 与跨batch(FLvsGC) 的 |NES| 对比
cross = pd.read_csv(os.path.join(BASE, "GSEA_NES_animal.txt"), sep='\t')
print(f"\n跨batch (FL vs GC, 主结果): |NES|max={abs(cross.NES).max():.2f}, 中位|NES|={abs(cross.NES).median():.2f}, 显著 {(cross.FWER_p<0.05).sum()}")
