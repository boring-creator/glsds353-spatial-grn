# -*- coding: utf-8 -*-
"""从 ISON 12 切片输出构建 LINGER scNN 的 TG/RE pseudobulk 输入。

按 ISON 论文（Dehnath & Duren, Nat Comm 2026）Methods 复现：
  "Cell type annotation and pseudo-bulking":
    log 变换 -> PCA -> Harmony 批校正 -> Leiden 聚类成细胞类型
    -> 按 batch(切片) × 细胞类型 分组，聚合 spot 表达 -> TG/RE pseudobulk

说明：
  - 论文用"聚合 counts"(求和)；我们的 RNA 是 ISON 去噪重建值、ATAC 是预测可及性
    （非 counts），故用 mean 聚合（组间 spot 数不等时更稳健）。
  - LINGER sc_nn_NN 会对输入特征做 z-score 标准化，mean/sum 的尺度差异不影响模型。

输出到 /root/autodl-tmp/linger/data/：
  TG_pseudobulk.tsv  (基因 × 组, 逗号分隔, index=基因, header=组名 "切片_细胞类型")
  RE_pseudobulk.tsv  (peak × 组, 逗号分隔, index=peak)
  Peaks.txt          (peak 坐标 chr:start-end, 一行一个)
  spot_celltype.tsv  (每 spot 的 sample/celltype 映射, 供下游空间分析)

依赖：base env（scanpy + harmonypy，AutoDL 镜像自带 scanpy，需 pip install harmonypy）。
"""
import os
import numpy as np
import pandas as pd
import scanpy as sc
from anndata import concat

SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]
DATA = "/root/autodl-tmp/ison_data"
WORK = "/root/autodl-tmp/linger"
DATA_DIR = os.path.join(WORK, "data")
os.makedirs(DATA_DIR, exist_ok=True)
OUTSUB = "output_v2"   # 2026-08-04 重跑（保留 TF 参考）输出目录；旧版用 "output"

# ---------- 1. 读入 12 切片 ----------
print("[1] 读入 12 切片 RNA + ATAC ...", flush=True)
rna_list, atac_list = [], []
for s in SLICES:
    r = sc.read_h5ad(f"{DATA}/{s}/{OUTSUB}/{s}-RNA.h5ad")
    a = sc.read_h5ad(f"{DATA}/{s}/{OUTSUB}/{s}-ATAC.h5ad")
    r.obs["sample"] = s
    a.obs["sample"] = s
    r.obs["barcode"] = r.obs_names.astype(str)
    a.obs["barcode"] = a.obs_names.astype(str)
    rna_list.append(r); atac_list.append(a)

rna = concat(rna_list, join="outer")
atac = concat(atac_list, join="outer")
rna.X = np.nan_to_num(np.asarray(rna.X, dtype=np.float32))
atac.X = np.nan_to_num(np.asarray(atac.X, dtype=np.float32))
print(f"    RNA: {rna.shape} | ATAC: {atac.shape}", flush=True)

# peak 命名一致性（共享参考，应一致）
p0 = list(atac.var_names)
for i in range(1, 12):
    assert list(atac_list[i].var_names) == p0, f"peak 顺序不一致 at {SLICES[i]}"
print("    [OK] peak var_names 跨切片一致", flush=True)

# ---------- 2. 细胞类型聚类（log->PCA->Harmony->Leiden，论文方法）----------
print("[2] Harmony + Leiden 聚细胞类型 ...", flush=True)
adata = rna.copy()
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.pca(adata, n_comps=30)
import harmonypy as hm
ho = hm.run_harmony(adata.obsm["X_pca"], adata.obs[["sample"]], "sample",
                    max_iter_harmony=20, verbose=False, random_state=0)
Z = np.asarray(ho.Z_corr)
print(f"    [debug] Z_corr shape: {Z.shape}", flush=True)
adata.obsm["X_pca_harmony"] = Z if Z.shape[0] == adata.n_obs else Z.T
sc.pp.neighbors(adata, use_rep="X_pca_harmony", n_neighbors=15)
# 分辨率 0.3：分辨率扫描选定（18 类，伪bulk组最稳健），见 sweep_resolution.py
sc.tl.leiden(adata, resolution=0.3, key_added="celltype")
n_ct = adata.obs["celltype"].nunique()
print(f"    [OK] 细胞类型数 = {n_ct}", flush=True)
print(adata.obs["celltype"].value_counts().to_string(), flush=True)

# ---------- 3. 按 切片×细胞类型 聚合（mean，论文 pseudo-bulking）----------
print("[3] 按 切片×细胞类型 聚合（mean）...", flush=True)
rna.obs["celltype"] = adata.obs["celltype"].values
atac.obs["celltype"] = adata.obs["celltype"].values

def agg_mean(X, obs_df, group_cols):
    """X: n×p (dense), 返回 (p×g) DataFrame, 列为 group"""
    grp = obs_df[group_cols].astype(str).agg("_".join, axis=1)
    groups = sorted(grp.unique())
    out = np.zeros((len(groups), X.shape[1]), dtype=np.float64)
    for i, g in enumerate(groups):
        out[i] = X[grp.values == g].mean(axis=0)
    return pd.DataFrame(out.T, index=np.arange(X.shape[1]), columns=groups)

TG = agg_mean(np.asarray(rna.X), rna.obs, ["sample", "celltype"])
RE = agg_mean(np.asarray(atac.X), atac.obs, ["sample", "celltype"])
TG.index = rna.var_names
RE.index = atac.var_names
print(f"    TG_pseudobulk: {TG.shape} | RE_pseudobulk: {RE.shape}", flush=True)

# ---------- 4. 写出 ----------
print("[4] 写输出 ...", flush=True)
with open(os.path.join(DATA_DIR, "Peaks.txt"), "w") as f:
    f.write("\n".join(atac.var_names.astype(str)) + "\n")
TG.to_csv(os.path.join(DATA_DIR, "TG_pseudobulk.tsv"))
RE.to_csv(os.path.join(DATA_DIR, "RE_pseudobulk.tsv"))
spot_meta = pd.DataFrame({"sample": adata.obs["sample"].values,
                          "celltype": adata.obs["celltype"].values},
                         index=adata.obs_names.astype(str))
spot_meta.to_csv(os.path.join(WORK, "spot_celltype.tsv"), sep="\t")
print("[DONE] 构建完成", flush=True)
print("    Peaks.txt:", sum(1 for _ in open(os.path.join(DATA_DIR, "Peaks.txt"))), "peaks", flush=True)
print("    组列数:", TG.shape[1], "（切片 × 细胞类型）", flush=True)
print("    前 3 组列名:", list(TG.columns[:3]), flush=True)
