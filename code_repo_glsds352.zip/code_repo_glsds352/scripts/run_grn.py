# -*- coding: utf-8 -*-
"""run_grn.py — 从 scNN 输出生成细胞群体 GRN（cis/trans/TF-RE 结合）。

scNN 方法下三个函数都不需要 adata（只用 load_data_scNN + grn_out 的 net/shap）。
genome 传 'New'（我们的 provide_data 是 MotifMatch.txt，load_data_scNN 用 'New' 分支）。

用法（scnn_paper env，cwd=/root/autodl-tmp/linger）：
  python run_grn.py
输出（grn_out/）：
  cell_population_cis_regulatory.txt   (RE, TG, cis_score)
  cell_population_trans_regulatory.txt (TF × TG 矩阵, trans_score)
  cell_population_TF_RE_binding.txt    (TF-RE 结合矩阵)
  {chr}_cell_population_TF_RE_binding.txt
"""
import time
import pandas as pd
import LingerGRN.LL_net as LL

GRNdir = "/root/autodl-tmp/scnn/provide_data/"
outdir = "/root/autodl-tmp/linger/grn_out/"
t0 = time.time()

print("[1/3] cis_reg ...", flush=True)
LL.cis_reg(GRNdir, None, None, "New", "scNN", outdir)
print(f"    [OK] cell_population_cis_regulatory.txt ({time.time()-t0:.0f}s)", flush=True)

print("[2/3] trans_reg ...", flush=True)
LL.trans_reg(GRNdir, "scNN", outdir, "New")
print(f"    [OK] cell_population_trans_regulatory.txt ({time.time()-t0:.0f}s)", flush=True)

print("[3/3] TF_RE_binding ...", flush=True)
LL.TF_RE_binding(GRNdir, None, None, "New", "scNN", outdir)
print(f"    [OK] cell_population_TF_RE_binding.txt ({time.time()-t0:.0f}s)", flush=True)

print(f"[DONE] GRN 生成完成，总耗时 {(time.time()-t0)/60:.1f} min", flush=True)
