# plot_marker_spatial.R — ⑤ Marker 增强子共定位空间图（ggplot2，R）
# 每个 marker：左=表达空间图，右=预测 ATAC（该 marker 的启动子/增强子 peak）空间图
suppressMessages({library(ggplot2); library(dplyr)})

dat <- read.csv("C:/Users/aguang/Downloads/Desktop/sci/spatial_marker_data.csv")
outdir <- "C:/Users/aguang/Downloads/Desktop/sci/figures/"
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

for (s in unique(dat$slice)) {
  sub <- dat[dat$slice == s, ]
  for (m in unique(sub$marker)) {
    sm <- sub[sub$marker == m, ]
    peak <- sm$peak[1]
    p1 <- ggplot(sm, aes(x, y, color = expr)) + geom_point(size = 0.8) +
      scale_color_gradient(low = "grey90", high = "darkred", name = "表达") +
      ggtitle(paste0(s, " | ", m, " 表达")) + theme_minimal() + coord_fixed()
    p2 <- ggplot(sm, aes(x, y, color = atac)) + geom_point(size = 0.8) +
      scale_color_gradient(low = "grey90", high = "navy", name = "ATAC") +
      ggtitle(paste0(s, " | ", m, " peak ", peak)) + theme_minimal() + coord_fixed()
    ggsave(file.path(outdir, paste0(s, "_", m, "_expr.png")), p1, width = 5, height = 5, dpi = 150)
    ggsave(file.path(outdir, paste0(s, "_", m, "_atac.png")), p2, width = 5, height = 5, dpi = 150)
  }
}
cat("空间图已保存到 figures/\n")
