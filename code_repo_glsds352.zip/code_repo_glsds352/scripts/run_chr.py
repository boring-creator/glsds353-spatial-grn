# -*- coding: utf-8 -*-
"""run_chr.py <chr> — 单个染色体的 LINGER scNN 训练（论文环境 scnn_paper）。

用法：python run_chr.py chr1     # 在 /root/autodl-tmp/linger 下
输出（与 training() 格式一致）：
  grn_out/{chr}_net.pt / {chr}_shap.pt / {chr}_Loss.txt
"""
import os
import sys
import numpy as np
import pandas as pd
import torch

import LingerGRN.LINGER_tr as LT

GRNdir = "/root/autodl-tmp/scnn/provide_data/"
outdir = "/root/autodl-tmp/linger/grn_out/"
chr_target = sys.argv[1]
L1, ACTIVE = 0.01, "ReLU"

os.makedirs(outdir, exist_ok=True)
Exp, Opn, Target, RE_TGlink = LT.load_data_scNN(GRNdir, "New")
# ⚠️ 修复：load_data_scNN 的 groupby 行序跨进程不稳定（hash seed），
# 必须按基因排序，保证 net/shap 与 RE_TGlink.txt 对齐
RE_TGlink = RE_TGlink.sort_values("gene").reset_index(drop=True)
chrall = [RE_TGlink[0].iloc[i][0].split(":")[0] for i in range(RE_TGlink.shape[0])]
RE_TGlink["chr"] = chrall
RE_TGlink1 = RE_TGlink[RE_TGlink["chr"] == chr_target]
rows = RE_TGlink1.values
n = rows.shape[0]

netall_s, shapall_s = {}, {}
Lossall = np.zeros([n, 100])
for ii in range(n):
    torch.set_num_threads(1)
    res = LT.sc_nn_NN(ii, rows[ii], Target, Exp, Opn, L1, ACTIVE)
    netall_s[ii] = res[0]
    shapall_s[ii] = res[1]
    Lossall[ii, :] = np.asarray(res[2]).T
torch.save(netall_s, outdir + chr_target + "_net.pt")
torch.save(shapall_s, outdir + chr_target + "_shap.pt")
Lossall = pd.DataFrame(Lossall)
Lossall.index = RE_TGlink1["gene"].values
Lossall.to_csv(outdir + chr_target + "_Loss.txt", sep="\t")
print(f"[{chr_target}] {n} 基因完成，已存盘", flush=True)
