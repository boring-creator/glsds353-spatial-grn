#!/usr/bin/env Rscript
# plot_fig2.R — 图二：内部一致性（主验证三强项，见交接文档 §1 发布注意）
#   A. Moran's I 空间自相关（④ 强）      B. 参考 Multiome 锚定 0.80（强）
#   C. marker 增强子共定位（⑤ 强，代表切片）
# 弱验证（距离衰减/模块一致性/20kb Fisher）→ 补充图，不进主图
suppressMessages({library(ggplot2); library(dplyr); library(patchwork)})
base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
L <- file.path(base, "linger_outputs")
# 动物-切片 ID（与图一统一）：FL 上排序 + GC 下排序
anim_lab <- c("158_A1"="F2·A1","158_B1"="F2·B1","158_C1"="F7·C1","158_D1"="F7·D1",
              "159_C1"="F1·C1","159_D1"="F1·D1","159_A1"="G7·A1","159_B1"="G7·B1",
              "304_A1"="G9·A1","304_B1"="G9·B1","304_C1"="G8·C1","304_D1"="G8·D1")
lab_order2 <- c("F2·A1","F2·B1","F7·C1","F7·D1","F1·C1","F1·D1",
                "G7·A1","G7·B1","G9·A1","G9·B1","G8·C1","G8·D1")

# ---- Panel A: Moran's I ----
mr <- read.delim(file.path(L, "moran_results.tsv"))
mr$lab <- factor(anim_lab[as.character(mr$slice)], levels = lab_order2)
pA <- ggplot(mr, aes(lab, moran_I, fill = lab)) +
  geom_violin(width = 0.9, alpha = 0.65, scale = "width") +
  stat_summary(fun = median, geom = "point", size = 1.4, color = "black") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.7) +
  scale_fill_manual(values = rep("darkorange", length(lab_order2)), guide = "none") +
  labs(x = NULL, y = "Moran's I (per peak)",
       title = "A  Spatial autocorrelation of predicted ATAC") +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, fontface = "plain"),
        plot.title = element_text(hjust = 0, face = "bold", size = 12))

# ---- Panel B: 参考锚定 ----
ra <- read.delim(file.path(L, "ref_anchor_results.tsv"))
ra$lab <- factor(anim_lab[as.character(ra$slice)], levels = lab_order2)
pB <- ggplot(ra, aes(lab, pcc, fill = lab)) +
  geom_violin(width = 0.9, alpha = 0.65, scale = "width") +
  stat_summary(fun = median, geom = "point", size = 1.4, color = "black") +
  geom_hline(yintercept = 0.8, linetype = "dashed", color = "black", linewidth = 0.7) +
  scale_fill_manual(values = rep("#377eb8", length(lab_order2)), guide = "none") +
  labs(x = NULL, y = "Per-spot PCC (predicted vs reference-anchored ATAC)",
       title = "B  Cross-modality agreement with reference Multiome (mean 0.80)") +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, fontface = "plain"),
        plot.title = element_text(hjust = 0, face = "bold", size = 12))

# ---- Panel C: marker 共定位（代表切片 159_C1，Egr1/Mbp/Nrgn）----
md <- read.csv(file.path(base, "spatial_marker_data.csv"))
md$slice <- factor(md$slice)
sel <- md[md$slice == "159_C1" & md$marker %in% c("Egr1", "Mbp", "Nrgn"), ]
markers_c <- c("Egr1", "Mbp", "Nrgn")
sel$marker <- factor(sel$marker, levels = markers_c)
col_plots <- lapply(markers_c, function(m) {
  d <- sel[sel$marker == m, ]
  p1 <- ggplot(d, aes(x, y, color = expr)) + geom_point(size = 0.5) +
    scale_color_gradient(low = "grey90", high = "darkred", name = "RNA") +
    labs(x = NULL, y = NULL, title = bquote(italic(.(m)) ~ .("expression"))) +
    theme_void() + theme(plot.title = element_text(size = 9, hjust = 0.5),
                         legend.key.size = unit(0.3, "cm"))
  p2 <- ggplot(d, aes(x, y, color = atac)) + geom_point(size = 0.5) +
    scale_color_gradient(low = "grey90", high = "navy", name = "ATAC") +
    labs(x = NULL, y = NULL, title = bquote(italic(.(m)) ~ .("promoter/enhancer ATAC"))) +
    theme_void() + theme(plot.title = element_text(size = 9, hjust = 0.5),
                         legend.key.size = unit(0.3, "cm"))
  p1 | p2
})
pC <- wrap_plots(col_plots, ncol = 1) +
  plot_annotation(title = "C  Marker gene expression vs predicted ATAC co-localization (159_C1)",
                  theme = theme(plot.title = element_text(face = "bold", size = 12, hjust = 0)))

# ---- 合并 ----
fig <- (pA | pB) / pC + plot_layout(heights = c(1, 1.2)) +
  plot_annotation(
    title = "Figure 2 | Internal consistency of ISON-predicted spatial ATAC",
    theme = theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold")))
ggsave(file.path(outdir, "Fig2_internal_consistency.png"), fig,
       width = 14, height = 12, dpi = 300, limitsize = FALSE)
cat("[DONE] figures/Fig2_internal_consistency.png\n")
