# -*- coding: utf-8 -*-
"""run_scnn.py — LINGER scNN 训练驱动（串行，后台运行）。

问题：shap 0.49 + torch 2.5.1 的 DeepExplainer additivity 校验过严，
标准 MLP 也报 max diff ~3.94 > 容差 0.01。
解法：运行时 monkeypatch shap 默认 check_additivity=False。
（不修改 LINGER 源码；SHAP 值仍按模型梯度路径正常计算，校验仅是验证性质。）

用法（LINGER env，cwd=/root/autodl-tmp/linger）：
  nohup python run_scnn.py > scnn.log 2>&1 &
"""
import os
import time
import shap

# monkeypatch：默认关闭 additivity 校验（shap/torch 版本兼容，未改 LINGER 源码）
_orig = shap.DeepExplainer.shap_values
def _patched(self, X, ranked_outputs=None, output_rank_order="max", check_additivity=False):
    return _orig(self, X, ranked_outputs, output_rank_order, check_additivity)
shap.DeepExplainer.shap_values = _patched
print("[OK] shap additivity 校验已关闭（monkeypatch，源码未动）", flush=True)

import LingerGRN.LINGER_tr as LT

GRNdir = "/root/autodl-tmp/scnn/provide_data/"   # 必须带尾斜杠
outdir = "/root/autodl-tmp/linger/grn_out/"
os.makedirs(outdir, exist_ok=True)

t0 = time.time()
print(f"[start] {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
LT.training(GRNdir, "scNN", outdir, "ReLU", "New")
print(f"[DONE] scNN 训练完成，耗时 {(time.time()-t0)/60:.1f} min", flush=True)
