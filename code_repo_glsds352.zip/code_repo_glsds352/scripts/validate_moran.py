# -*- coding: utf-8 -*-
"""validate_moran.py — 验证④：Moran's I 空间自相关（论文同款 squidpy）

对每张切片预测 ATAC，逐 peak 计算 Moran's I（squidpy），看：
  - Moran's I 分布（应多数 >0，有空间结构）
  - 高自相关 peak 是否对应海马亚区（配作者注释/空间图）

输入：ison_outputs_v2/{切片}/{切片}-ATAC.h5ad + 本地 coords（E:\space\ison_data\{切片}\coords.csv）
用法：E:/miniconda/envs/ison_env/python.exe validate_moran.py [切片]
"""
import os
import sys
import numpy as np
import pandas as pd
import scanpy as sc
import squidpy as sq

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "ison_outputs_v2")
COORD = r"E:\space\ison_data"
SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]

def moran_slice(s):
    ad = sc.read_h5ad(os.path.join(OUT, s, f"{s}-ATAC.h5ad"))
    coords = pd.read_csv(os.path.join(COORD, s, "coords.csv"), index_col=0)
    coords = coords.loc[ad.obs_names]
    ad.obsm["spatial"] = coords[["x", "y"]].values
    sq.gr.spatial_neighbors(ad, coord_type="generic", n_neighs=8)
    sq.gr.moran(ad, use_raw=False)
    mi = ad.obs[[f"Moran's I of {pk}" for pk in list(ad.var_names[:1])]]  # 示例占位
    moran_cols = [c for c in ad.obs.columns if c.startswith("Moran's I")]
    vals = ad.obs[moran_cols].values  # (n_spot, n_peak)
    return vals, ad.var_names

if __name__ == "__main__":
    targets = sys.argv[1:] or SLICES
    for s in targets:
        p = os.path.join(OUT, s, f"{s}-ATAC.h5ad")
        if not os.path.exists(p):
            print(f"[SKIP] {s}: 未下载")
            continue
        ad = sc.read_h5ad(p)
        coords = pd.read_csv(os.path.join(COORD, s, "coords.csv"), index_col=0).loc[ad.obs_names]
        ad.obsm["spatial"] = coords[["x", "y"]].values
        sq.gr.spatial_neighbors(ad, coord_type="generic", n_neighs=8)
        sq.gr.spatial_autocorr(ad, mode="moran", n_perms=None)
        moran_df = ad.uns["moranI"]
        vals = moran_df["I"].values.astype(float)
        print(f"=== {s}: {ad.shape}, {len(vals)} peaks ===")
        print(f"  Moran's I 中位: {np.median(vals):.3f} | >0 比例: {(vals>0).mean()*100:.1f}%")
        print(f"  top5 自相关 peak: {list(moran_df.index[np.argsort(vals)[-5:]])}")
        pd.DataFrame({"slice": s, "peak": moran_df.index, "moran_I": vals}).to_csv(
            os.path.join(BASE, "linger_outputs", "moran_results.tsv"),
            sep="\t", index=None, mode="a",
            header=not os.path.exists(os.path.join(BASE, "linger_outputs", "moran_results.tsv")))
        print(f"[SAVED append] moran_results.tsv ({s})")
