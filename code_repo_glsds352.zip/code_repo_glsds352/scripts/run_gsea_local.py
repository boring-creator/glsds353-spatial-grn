# -*- coding: utf-8 -*-
"""run_gsea_local.py — 本地跑 FL vs GC 模块 GSEA（对应 ISON 论文 Fig 5d）
输入（linger_outputs/）：
  gene_modules.txt   gene → module(0-11)
  logFC_FLvsGC.txt   gene × celltype（FL vs GC log2FC）
输出：
  GSEA_NES_celltype_module.txt
用法：E:/miniconda/envs/ison_env/python.exe run_gsea_local.py
"""
import os
import numpy as np
import pandas as pd
import gseapy as gp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
logFC = pd.read_csv(os.path.join(BASE, "logFC_FLvsGC.txt"), sep="\t", index_col=0)
print("模块数:", modules.module.nunique(), "| logFC 细胞类型:", list(logFC.columns))

module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}
size = {k: len(v) for k, v in module_sets.items()}
print("模块大小:", size)

nes_rows = []
for ct in logFC.columns:
    r = logFC[ct].dropna()
    if len(r) < 10:
        continue
    ranks = r.sort_values(ascending=False)
    pre = gp.prerank(rnk=ranks, gene_sets=module_sets, min_size=3, max_size=2000,
                     permutation_num=1000, seed=42, no_plot=True, outdir=None)
    for _, row in pre.res2d.iterrows():
        nes_rows.append({"celltype": ct, "module": row["Term"],
                         "NES": row["NES"], "FWER_p": row["FWER p-val"]})
    print(f"  [{ct}] 完成, NES 显著(<0.05): {(pre.res2d['FWER p-val'] < 0.05).sum()}", flush=True)

nes = pd.DataFrame(nes_rows)
nes.to_csv(os.path.join(BASE, "GSEA_NES_celltype_module.txt"), sep="\t", index=None)
print(f"[DONE] GSEA: {nes.shape}")
# 打印显著项
sig = nes[nes.FWER_p < 0.05]
if len(sig):
    print("=== 显著模块×细胞类型 (FWER<0.05) ===")
    print(sig.sort_values('NES', ascending=False).to_string(index=False))
else:
    print("无 FWER<0.05 的显著项；看一下 NES 分布:")
    print(nes.groupby('module')['NES'].mean().sort_values(ascending=False).to_string())
