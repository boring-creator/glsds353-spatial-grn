# -*- coding: utf-8 -*-
"""generate_marker_159.py — 生成 159 批次（G7-GC vs F1-FL）marker 空间数据（图五）
与既有 spatial_marker_data.csv 同法：每 marker 取 top promoter/enhancer peak，
expr=RNA[spot,gene], atac=ATAC[spot,peak]。
输入: ison_outputs_v2/{s}/*-{RNA,ATAC}.h5ad + E:\space\ison_data\{s}\coords.csv
输出: marker_159_data.csv
用法: E:/miniconda/envs/valenv/python.exe generate_marker_159.py
"""
import os
import numpy as np
import pandas as pd
import scanpy as sc

BASE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(BASE, "ison_outputs_v2")
COORD = r"E:\space\ison_data"
SLICES = ["159_A1", "159_B1", "159_C1", "159_D1"]
MARKERS = ["Egr1", "Mbp", "Nr3c1", "Nrgn", "Slc17a7"]   # Wfs1 无表达，跳过

peak_of = {
    "Egr1": "chr18:34859467-34860217",
    "Mbp":  "chr18:82471657-82472581",
    "Nr3c1": "chr18:39489449-39490241",
    "Nrgn": "chr9:37552308-37553179",
    "Slc17a7": "chr7:45161814-45162725",
}

rows = []
for s in SLICES:
    rna = sc.read_h5ad(os.path.join(OUT, s, f"{s}-RNA.h5ad"))
    atac = sc.read_h5ad(os.path.join(OUT, s, f"{s}-ATAC.h5ad"))
    coords = pd.read_csv(os.path.join(COORD, s, "coords.csv"), index_col=0)
    Xr = rna.X.toarray() if hasattr(rna.X, "toarray") else np.asarray(rna.X)
    Xa = atac.X.toarray() if hasattr(atac.X, "toarray") else np.asarray(atac.X)
    gi = {g: i for i, g in enumerate(rna.var_names)}
    pi = {p: i for i, p in enumerate(atac.var_names)}
    for m in MARKERS:
        if m not in gi or peak_of[m] not in pi:
            print(f"  [{s}] {m}: 缺基因或peak", flush=True); continue
        for i, bc in enumerate(rna.obs_names):
            if bc not in coords.index:
                continue
            x, y = coords.loc[bc, ["x", "y"]]
            rows.append({"slice": s, "spot": bc, "x": x, "y": y,
                         "marker": m, "peak": peak_of[m],
                         "expr": float(Xr[i, gi[m]]), "atac": float(Xa[i, pi[peak_of[m]]])})
    print(f"  [{s}] 完成", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(BASE, "marker_159_data.csv"), index=None)
print("[DONE] marker_159_data.csv", df.shape)
