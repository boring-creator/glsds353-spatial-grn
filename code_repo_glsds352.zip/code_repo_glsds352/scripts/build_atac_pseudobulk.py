# -*- coding: utf-8 -*-
"""build_atac_pseudobulk.py — 构建预测 ATAC 伪 bulk 计数矩阵（DESeq2 路线 A 输入）

流程.md 路线 A：每张切片的预测 ATAC 在 spots 上聚合 → 12 个伪 bulk 样本 → DESeq2
- ISON 预测 ATAC 为连续 accessibility 值（1.9e-11 ~ 4307）→ 跨 spot 求和后取整作为
  伪 count（预测值非真实 read count，取整为 DESeq2 数值近似，正文需注明局限）

FL/GC 分组（ISON运行汇总.md §6.2）:
  FL = 158_A1/B1/C1/D1 + 159_C1/D1 (6 张)
  GC = 159_A1/B1 + 304_A1/B1/C1/D1  (6 张)

输入: ison_outputs_v2/{切片}/*-ATAC.h5ad
输出:
  linger_outputs/ATAC_pseudobulk_counts.tsv  peak × 12 切片（整数 count）
  linger_outputs/ATAC_pseudobulk_meta.tsv     切片 × (batch, group, brain)
用法: E:/miniconda/envs/valenv/python.exe build_atac_pseudobulk.py
"""
import os
import numpy as np
import pandas as pd
import anndata as ad

BASE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(BASE, "linger_outputs")
SLICES = ["158_A1", "158_B1", "158_C1", "158_D1",
          "159_A1", "159_B1", "159_C1", "159_D1",
          "304_A1", "304_B1", "304_C1", "304_D1"]

# 脑 / 组 / 批次（ISON运行汇总.md §6.2）
meta = [
    ("158_A1", "F2", "FL", "158"), ("158_B1", "F2", "FL", "158"),
    ("158_C1", "F7", "FL", "158"), ("158_D1", "F7", "FL", "158"),
    ("159_A1", "G7", "GC", "159"), ("159_B1", "G7", "GC", "159"),
    ("159_C1", "F1", "FL", "159"), ("159_D1", "F1", "FL", "159"),
    ("304_A1", "G9", "GC", "304"), ("304_B1", "G9", "GC", "304"),
    ("304_C1", "G8", "GC", "304"), ("304_D1", "G8", "GC", "304"),
]
metadf = pd.DataFrame(meta, columns=["slice", "brain", "group", "batch"])
metadf.to_csv(os.path.join(OUT, "ATAC_pseudobulk_meta.tsv"), sep="\t", index=None)
print("分组: FL %d 张, GC %d 张" % ((metadf.group == "FL").sum(), (metadf.group == "GC").sum()))

cols = {}
for s in SLICES:
    f = os.path.join(BASE, "ison_outputs_v2", s, f"{s}-ATAC.h5ad")
    a = ad.read_h5ad(f)
    X = a.X
    if hasattr(X, "toarray"):
        X = X.toarray()
    cols[s] = X.sum(axis=0)                     # 跨 spot 求和
    print(f"  [{s}] spots={X.shape[0]} peaks={X.shape[1]} "
          f"pseudobulk 范围 {cols[s].min():.0f}~{cols[s].max():.0f}", flush=True)

pk = pd.DataFrame(cols).astype(np.float64)
pk = pk.round().astype(np.int64)                # 取整作伪 count
pk.index = a.var.index
pk = pk.loc[open(os.path.join(OUT, "Peaks.txt")).read().split()]  # 对齐 Peaks.txt 顺序
pk.to_csv(os.path.join(OUT, "ATAC_pseudobulk_counts.tsv"), sep="\t")
print(f"[DONE] ATAC_pseudobulk_counts: {pk.shape}")
print("每切片总 count(×1e6):", (pk.sum(axis=0) / 1e6).round(1).to_dict())
