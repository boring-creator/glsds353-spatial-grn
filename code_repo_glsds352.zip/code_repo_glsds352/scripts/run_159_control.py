# -*- coding: utf-8 -*-
"""run_159_control.py — 159 批次内部对照验证 FL vs GC（批次混杂兜底）

设计依据（ISON运行汇总.md §6.2 样本配对表）:
  159 批次同时含 G7(GC, 159_A1/B1) 和 F1(FL, 159_C1/D1)，是同批次内最干净的
  FL vs GC 对照；158 全飞行、304 全地面 → 批次与组部分混杂。
  若 FL vs GC 信号是真实的，159 批次内部对照应保留一致方向；若主要由 304(全GC)
  低质量驱动，则 159 内部对照会减弱/消失。

方法：与 run_downstream.py 完全一致——
  logFC(ct) = log2( mean(FL_159 伪bulk+1) / mean(GC_159 伪bulk+1) )
  gseapy.prerank 每细胞类型（min_size=3, max_size=2000, perm=1000, seed=42）

输入:
  linger_outputs/TG_pseudobulk.tsv    基因 × 88 组（切片_细胞类型）
  linger_outputs/gene_modules.txt     12 模块基因集
  linger_outputs/GSEA_NES_animal.txt  全量动物级 GSEA（对比用，Fig 4A 主结果）
输出:
  linger_outputs/logFC_159_only.tsv
  linger_outputs/GSEA_159_control.tsv
  figures/GSEA_159_vs_full.png        全量 vs 159 内部对照 NES 对比
用法:
  E:/miniconda/envs/ison_env/python.exe run_159_control.py
"""
import os
import numpy as np
import pandas as pd
import gseapy as gp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
FIG  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(FIG, exist_ok=True)

FL159 = {"159_C1", "159_D1"}   # 飞行 rep1 (F1)
GC159 = {"159_A1", "159_B1"}   # 地面 rep1 (G7)

# ---------- 1) 159-only logFC（方法同 run_downstream.py）----------
TG = pd.read_csv(os.path.join(BASE, "TG_pseudobulk.tsv"), sep=",", index_col=0)
gdf = pd.DataFrame({"group": TG.columns,
                    "sample": [g.rsplit("_", 1)[0] for g in TG.columns],
                    "ct": [g.rsplit("_", 1)[1] for g in TG.columns]})
gdf["cond"] = gdf["sample"].apply(lambda s: "FL" if s in FL159 else
                                  ("GC" if s in GC159 else "out"))
g159 = gdf[gdf.cond.isin(["FL", "GC"])]
print("159 批次组数:", len(g159), "| 各条件:", g159.cond.value_counts().to_dict())

cts = sorted(set(g159[g159.cond == "FL"].ct) & set(g159[g159.cond == "GC"].ct))
print("159 内可对照细胞类型:", cts)
logFC = pd.DataFrame(index=TG.index)
for ct in cts:
    fl = TG[g159[(g159.ct == ct) & (g159.cond == "FL")].group].mean(axis=1)
    gc = TG[g159[(g159.ct == ct) & (g159.cond == "GC")].group].mean(axis=1)
    logFC[ct] = np.log2((fl + 1) / (gc + 1))
logFC.to_csv(os.path.join(BASE, "logFC_159_only.txt"), sep="\t")
print(f"[DONE] logFC_159_only: {logFC.shape}")

# ---------- 2) GSEA prerank（每细胞类型，同参数）----------
modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}
rows = []
for ct in cts:
    r = logFC[ct].dropna()
    if len(r) < 10:
        continue
    ranks = r.sort_values(ascending=False)
    pre = gp.prerank(rnk=ranks, gene_sets=module_sets, min_size=3, max_size=2000,
                     permutation_num=1000, seed=42, no_plot=True, outdir=None)
    for _, row in pre.res2d.iterrows():
        rows.append({"celltype": ct, "module": row["Term"],
                     "NES": row["NES"], "FWER_p": row["FWER p-val"]})
    nsig = (pre.res2d["FWER p-val"] < 0.05).sum()
    print(f"  [ct {ct}] 159-only GSEA 完成, 显著 {nsig} 项", flush=True)
g159_out = pd.DataFrame(rows)
g159_out.to_csv(os.path.join(BASE, "GSEA_159_control.tsv"), sep="\t", index=None)
print(f"[DONE] GSEA_159_control: {g159_out.shape}")

# ---------- 3) 与全量（动物级）GSEA 对比 ----------
full = pd.read_csv(os.path.join(BASE, "GSEA_NES_animal.txt"), sep="\t")
full["celltype"] = full.celltype.astype(str)
g159_out["celltype"] = g159_out.celltype.astype(str)
cmp = full.merge(g159_out, on=["celltype", "module"], suffixes=("_full", "_159"),
                 how="inner")
cmp = cmp.rename(columns={"NES_full": "NES_full", "NES_159": "NES_159",
                          "FWER_p_full": "p_full", "FWER_p_159": "p_159"})
print("\n=== 全量 vs 159 内部对照 NES 对比（共同 细胞类型×模块）===")
print(f"共同组合数: {len(cmp)}")
print("方向一致(同号)率: %.1f%%" % (100 * (np.sign(cmp.NES_full) == np.sign(cmp.NES_159)).mean()))
print("全量显著(全量 p<0.05)在 159 内部对照中仍显著率: %.1f%%" % (
    100 * cmp[cmp.p_full < 0.05].p_159.lt(0.05).mean()) if (cmp.p_full < 0.05).any() else "无全量显著项")

# 原 70 个显著组合在 159 内部对照的表现
sig_full = full[full.FWER_p < 0.05]
sig_cmp = sig_full.merge(g159_out, on=["celltype", "module"], suffixes=("_full", "_159"), how="left")
still_sig = sig_cmp[sig_cmp.FWER_p_159 < 0.05]
keep_dir = sig_cmp[np.sign(sig_cmp.NES_full) == np.sign(sig_cmp.NES_159)]
print(f"\n原全量显著组合 {len(sig_full)} 个 → 159 内部对照可查 {sig_cmp.NES_159.notna().sum()} 个:")
print(f"  159 仍显著: {len(still_sig)} 个 ({(100*len(still_sig)/len(sig_cmp)):.0f}%)")
print(f"  方向一致: {len(keep_dir)} 个 ({(100*len(keep_dir)/len(sig_cmp)):.0f}%)")
sig_cmp.to_csv(os.path.join(BASE, "GSEA_159_vs_full_sig.tsv"), sep="\t", index=None)

# ---------- 4) 对比图 ----------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
ax = axes[0]
for ct in sorted(cmp.celltype.unique()):
    d = cmp[cmp.celltype == ct]
    ax.scatter(d.NES_full, d.NES_159, s=30, alpha=0.7, label=f"ct {ct}")
lim = max(abs(np.nanmin(cmp[["NES_full", "NES_159"]].values)),
          abs(np.nanmax(cmp[["NES_full", "NES_159"]].values))) + 0.3
ax.plot([-lim, lim], [-lim, lim], "k--", lw=0.8)
ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
ax.axhline(0, color="grey", lw=0.5); ax.axvline(0, color="grey", lw=0.5)
ax.set_xlabel("NES (all samples)"); ax.set_ylabel("NES (159 batch only)")
ax.set_title("Module NES: full cohort vs 159 internal control")
ax.legend(fontsize=8, ncol=3, loc="lower right")

ax = axes[1]
d = cmp.dropna()
from scipy.stats import pearsonr, spearmanr
pc = pearsonr(d.NES_full, d.NES_159)[0] if len(d) > 2 else np.nan
sc_ = spearmanr(d.NES_full, d.NES_159)[0] if len(d) > 2 else np.nan
colors = np.where(d.p_159 < 0.05, "crimson", "steelblue")
ax.scatter(d.NES_full, d.NES_159, c=colors, alpha=0.75, s=35)
ax.plot([-lim, lim], [-lim, lim], "k--", lw=0.8)
ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim)
ax.axhline(0, color="grey", lw=0.5); ax.axvline(0, color="grey", lw=0.5)
ax.set_xlabel("NES (all)"); ax.set_ylabel("NES (159 only)")
ax.set_title(f"NES correlation (n={len(d)})\nPearson={pc:.3f}, Spearman={sc_:.3f}")
ax.legend(handles=[plt.Line2D([0],[0],marker="o",color="w",markerfacecolor="crimson",label="sig in 159"),
                   plt.Line2D([0],[0],marker="o",color="w",markerfacecolor="steelblue",label="ns in 159")],
          fontsize=9)
fig.suptitle("FL vs GC module GSEA — batch 159 internal control (G7-GC vs F1-FL)", fontsize=13, y=0.98)
plt.tight_layout(rect=[0, 0, 1, 0.94])
fig.savefig(os.path.join(FIG, "GSEA_159_vs_full.png"), dpi=300, bbox_inches="tight")
print("[DONE] 对比图:", os.path.join(FIG, "GSEA_159_vs_full.png"))
