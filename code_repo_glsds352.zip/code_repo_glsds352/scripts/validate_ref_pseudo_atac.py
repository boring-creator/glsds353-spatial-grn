# -*- coding: utf-8 -*-
"""validate_ref_pseudo_atac.py — 参考伪金标准验证（替代无金标准空间 ATAC）

思路：用参考 Multiome 的真实 scATAC 锚定预测：
  1. 参考细胞按作者 l4 注释聚成细胞类型 → 每类的真实 ATAC 均值谱 + RNA 均值谱
  2. 每 spot：用 ST 表达 NNLS 反卷积出细胞类型比例
  3. 期望 ATAC = Σ(比例 × 真实该类 ATAC)
  4. 预测 ATAC vs 期望 ATAC 相关（PCC）→ 用真实 ATAC 验证预测

用法：E:/miniconda/envs/valenv/python.exe validate_ref_pseudo_atac.py [切片]
"""
import os
import sys
import numpy as np
import pandas as pd
import scanpy as sc
from scipy.optimize import nnls
from scipy.stats import pearsonr

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "ison_outputs_v2")
META = r"E:\space\data\_tmp_meta\multiomics_final_objects_metadata\multiomics_brain_metadata_all_cells.csv"
REF_ATAC = r"E:\space\ison_data\atac.h5ad"
REF_RNA = r"E:\space\ison_data\rna.h5ad"
SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]

_cache = {}

def get_reference():
    if "ref" in _cache:
        return _cache["ref"]
    print("[1] 加载参考 + 注释 ...", flush=True)
    atac = sc.read_h5ad(REF_ATAC)
    rna = sc.read_h5ad(REF_RNA)
    meta = pd.read_csv(META, index_col=0)
    ct_col = "predicted.celltype.l4"
    common = list(set(atac.obs_names) & set(meta.index))
    meta = meta.loc[common]
    atac = atac[common]
    rna = rna[common]
    labels = meta[ct_col].astype(str).values
    # 细胞类型均值
    cts = sorted(set(labels))
    Xa = np.asarray(atac.X.toarray() if hasattr(atac.X, "toarray") else atac.X)
    Xr = np.asarray(rna.X.toarray() if hasattr(rna.X, "toarray") else rna.X)
    ct_atac = np.vstack([Xa[np.array(labels) == c].mean(axis=0) for c in cts])
    ct_rna = np.vstack([Xr[np.array(labels) == c].mean(axis=0) for c in cts])
    _cache["ref"] = (cts, ct_atac, ct_rna, atac.var_names, rna.var_names)
    print(f"    细胞类型数: {len(cts)}", flush=True)
    return _cache["ref"]

def validate_slice(s):
    cts, ct_atac, ct_rna, ref_peaks, ref_genes = get_reference()
    print(f"[2] 处理 {s} ...", flush=True)
    sprna = sc.read_h5ad(rf"E:\space\ison_data\{s}\sprna.h5ad")
    sc.pp.normalize_total(sprna, target_sum=1e4)
    sc.pp.log1p(sprna)
    atac_pred = sc.read_h5ad(os.path.join(OUT, s, f"{s}-ATAC.h5ad"))
    # 对齐基因（sprna ∩ ref_genes）
    shared = list(set(sprna.var_names) & set(ref_genes))
    rg = {g: i for i, g in enumerate(ref_genes)}
    Xr_s = np.asarray(sprna[:, shared].X.toarray())
    A_r = ct_rna[:, [rg[g] for g in shared]].T  # genes × celltypes
    # NNLS 反卷积每 spot
    Xs_raw = np.asarray(sprna.X.toarray()) if hasattr(sprna.X, "toarray") else np.asarray(sprna.X)
    Xs = Xs_raw[:, [sprna.var_names.get_loc(g) for g in shared]]
    props = np.zeros((Xs.shape[0], len(cts)))
    for i in range(Xs.shape[0]):
        sol, _ = nnls(A_r, Xs[i])
        props[i] = sol
    props = props / (props.sum(axis=1, keepdims=True) + 1e-12)
    # 期望 ATAC = Σ 比例 × 真实类ATAC（对齐 peak）
    pk = {p: i for i, p in enumerate(ref_peaks)}
    pred_peaks = list(atac_pred.var_names)
    A_atac = ct_atac[:, [pk[p] for p in pred_peaks]]  # celltypes × peaks
    exp_atac = props @ A_atac  # spots × peaks
    Xa = np.asarray(atac_pred.X)
    # 每 spot 相关（预测 vs 期望，跨 peak）
    cors = [pearsonr(Xa[i], exp_atac[i])[0] for i in range(Xa.shape[0])]
    # 存期望 ATAC（距离衰减复用）
    np.save(os.path.join(OUT, "npz", f"{s}_exp_atac.npy"), exp_atac)
    return np.mean(cors), np.median(cors), np.asarray(cors)

if __name__ == "__main__":
    targets = sys.argv[1:] or SLICES
    means = []
    for s in targets:
        p = os.path.join(OUT, s, f"{s}-ATAC.h5ad")
        if not os.path.exists(p):
            print(f"[SKIP] {s}")
            continue
        try:
            m, med, cors = validate_slice(s)
            means.append(m)
            print(f"  {s}: 预测vs期望ATAC PCC mean={m:.3f} median={med:.3f} (n={len(cors)} spots)", flush=True)
        except Exception as e:
            print(f"  {s}: 失败 {e}", flush=True)
    if means:
        print(f"\n=== 汇总: 跨切片 mean={np.mean(means):.3f} ===")
