#!/usr/bin/env Rscript
# plot_figs.R — 补充图 S：弱验证三件套（如实报告，进补充材料）
#   S-a 顺式调控距离衰减   S-b 模块一致性(RNA vs ATAC)   S-c 20kb Fisher(0/32)
suppressMessages({library(ggplot2); library(dplyr); library(patchwork)})
base <- "C:/Users/aguang/Downloads/Desktop/sci"
outdir <- file.path(base, "figures")
L <- file.path(base, "linger_outputs")

# ---- S-a: 距离衰减 ----
dd <- read.delim(file.path(L, "distance_decay_results.tsv"))
bin_levels <- c("<5kb", "5-10kb", "10-50kb", "50-100kb", "100-200kb", "200kb-1Mb")
dd$bin <- factor(dd$bin, levels = bin_levels)
dd_med <- dd %>% group_by(bin) %>%
  summarise(mid = median(median_pcc, na.rm = TRUE),
            q1 = quantile(median_pcc, 0.25, na.rm = TRUE),
            q3 = quantile(median_pcc, 0.75, na.rm = TRUE), .groups = "drop")
pA <- ggplot(dd_med, aes(x = as.numeric(bin), y = mid)) +
  geom_ribbon(aes(ymin = q1, ymax = q3), alpha = 0.2, fill = "#377eb8") +
  geom_point(size = 2.5, color = "#377eb8") + geom_line(color = "#377eb8", lwd = 0.8) +
  geom_jitter(data = dd, aes(x = as.numeric(bin), y = median_pcc),
              width = 0.12, size = 0.8, alpha = 0.4, color = "grey50") +
  scale_x_continuous(breaks = seq_along(bin_levels), labels = bin_levels) +
  labs(x = "Genomic distance (peak–gene)", y = "Median Pearson r (ATAC vs RNA)",
       title = "S-a  Cis-regulatory distance decay (weak gradient)") +
  theme_minimal(base_size = 11) + theme(plot.title = element_text(hjust = 0, face = "bold"))

# ---- S-b: 模块一致性 ----
mc <- read.delim(file.path(L, "module_consistency_results.tsv"))
pB <- ggplot(mc, aes(corr)) +
  geom_histogram(bins = 80, fill = "steelblue", color = "white", alpha = 0.85) +
  geom_vline(xintercept = 0.36, linetype = "dashed", color = "grey40") +
  annotate("text", x = 0.36, y = Inf, label = "mean 0.36", hjust = -0.1, vjust = 1.5, size = 3.5) +
  labs(x = "Spot-wise Pearson r (RNA vs ATAC module proportions)",
       y = "Spots", title = "S-b  RNA–ATAC module consistency (weak)") +
  theme_minimal(base_size = 11) + theme(plot.title = element_text(hjust = 0, face = "bold"))

# ---- S-c: 20kb Fisher ----
fk <- read.csv(file.path(L, "fisher20kb_results.csv"))
fk <- fk[fk$n_peaks >= 5, ]
fk$nlogP <- -log10(pmax(fk$p, 1e-12))
pC <- ggplot(fk, aes(x = factor(module), y = nlogP)) +
  geom_col(fill = ifelse(fk$adj_p < 0.05, "firebrick", "grey60"), width = 0.7) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "grey40") +
  labs(x = "Module", y = "-log10(Fisher p)",
       title = "S-c  20kb peak–gene association (0 significant modules)") +
  theme_minimal(base_size = 11) + theme(plot.title = element_text(hjust = 0, face = "bold"))

fig <- (pA / (pB | pC)) +
  plot_annotation(title = "Supplementary Figure S | Weak validations (reported honestly)",
                  theme = theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold")))
ggsave(file.path(outdir, "FigS_weak_validations.png"), fig,
       width = 13, height = 9, dpi = 300, limitsize = FALSE)
cat("[DONE] figures/FigS_weak_validations.png\n")
