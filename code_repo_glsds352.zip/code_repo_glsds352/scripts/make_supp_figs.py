# -*- coding: utf-8 -*-
"""make_supp_figs.py — 补充材料（数据离散度 / 离群样本透明展示，2026-08-05 v2）
S1: 12 切片 × 12 模块 归一化 ISON-predicted ATAC（标离群 158_D1）
Sx: M5 模块 ATAC 分布散点（FL vs GC，展示两组重叠 + 离群切片）
S2: Fig3A 全部模块 NES / FWER 完整表（动物级）
S3: TF 活性矩阵完整输出（linger_outputs/TF_activity.txt 即成品）
用法: E:/miniconda/envs/valenv/python.exe make_supp_figs.py
"""
import os
import ast
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

BASE = os.path.dirname(os.path.abspath(__file__))
L = os.path.join(BASE, "linger_outputs")
OUT = os.path.join(BASE, "figures")
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Helvetica", "Arial", "DejaVu Sans"]

ANIMAL = {"158_A1":"F2","158_B1":"F2","158_C1":"F7","158_D1":"F7",
          "159_C1":"F1","159_D1":"F1","159_A1":"G7","159_B1":"G7",
          "304_A1":"G9","304_B1":"G9","304_C1":"G8","304_D1":"G8"}
LAB = {"158_A1":"F2·A1","158_B1":"F2·B1","158_C1":"F7·C1","158_D1":"F7·D1",
       "159_C1":"F1·C1","159_D1":"F1·D1","159_A1":"G7·A1","159_B1":"G7·B1",
       "304_A1":"G9·A1","304_B1":"G9·B1","304_C1":"G8·C1","304_D1":"G8·D1"}
ORDER = ["158_A1","158_B1","158_C1","158_D1","159_C1","159_D1",
         "159_A1","159_B1","304_A1","304_B1","304_C1","304_D1"]
COND = {s: ("FL" if ANIMAL[s] in {"F1","F2","F7"} else "GC") for s in ORDER}
FC = {"FL": "#d1495b", "GC": "#377eb8"}
condA = np.array([COND[s] for s in ORDER])

# ---- 每模块 ATAC 分数（peak 按基因模块归并，per-peak z-score 后取均）----
mod = pd.read_csv(os.path.join(L, "gene_modules.txt"), sep="\t")
re = pd.read_csv(os.path.join(L, "RE_TGlink.txt"), sep="\t")
atac = pd.read_csv(os.path.join(L, "ATAC_pseudobulk_counts.tsv"), sep="\t", index_col=0)
re_dict = {}
for _, r in re.iterrows():
    try:
        re_dict[r["gene"]] = ast.literal_eval(r["0"])
    except Exception:
        pass

def module_atac(m):
    genes = mod[mod.module == m].gene.tolist()
    peaks = set()
    for g in genes:
        peaks.update(re_dict.get(g, []))
    peaks = [p for p in peaks if p in atac.index]
    sub = atac.loc[peaks]
    z = (sub - sub.mean(axis=1).values[:, None]) / (sub.std(axis=1).values[:, None] + 1e-9)
    return z.mean(axis=0).reindex(ORDER), len(peaks)

mod_atac = {}; mod_npk = {}
for m in range(12):
    s, n = module_atac(m)
    mod_atac[f"M{m}"] = s.values; mod_npk[f"M{m}"] = n
ms = pd.DataFrame(mod_atac, index=ORDER)   # 12 切片 × 12 模块

# ============================================================
# S1 —— 12 切片 × 12 模块 归一化 ATAC 表
# ============================================================
s1 = ms.copy()
s1.insert(0, "group", [COND[s] for s in ORDER])
s1.insert(1, "animal", [ANIMAL[s] for s in ORDER])
s1.insert(2, "batch", [s.split("_")[0] for s in ORDER])
s1.to_csv(os.path.join(L, "Supp_S1_module_ATAC.tsv"), sep="\t")
print("[S1] linger_outputs/Supp_S1_module_ATAC.tsv  (12 slices x 12 modules, z-normalized)")

fig, ax = plt.subplots(figsize=(17, 5))
ax.axis("off")
nmod = [f"M{m}" for m in range(12)]
cells = ms[nmod].round(2).values
tab = ax.table(cellText=cells, colLabels=nmod, rowLabels=[LAB[s] for s in ORDER],
               loc="center", cellLoc="center", colWidths=[0.055]*12)
tab.auto_set_font_size(False); tab.set_fontsize(7.5); tab.scale(1, 1.6)
for j in range(12):
    tab[0, j].set_facecolor("#444444"); tab[0, j].set_text_props(color="white", fontweight="bold")
for i in range(12):
    tab[i+1, 0].set_text_props(fontweight="bold")
    bg = "#fdeaea" if ORDER[i] == "158_D1" else ("#eef3fb" if COND[ORDER[i]]=="GC" else "white")
    for j in range(12):
        tab[i+1, j].set_facecolor(bg)
ax.set_title("Supplementary Table S1 | Module-normalized ISON-predicted ATAC per section (z-score per peak across sections)\n"
             "Outlier section 158_D1 (F7·D1, ~74x higher scale) highlighted in red",
             fontsize=11, fontweight="bold", pad=16)
fig.savefig(os.path.join(OUT, "FigS_S1_module_ATAC_table.png"), dpi=300, bbox_inches="tight")
print("[S1图] figures/FigS_S1_module_ATAC_table.png")

# ============================================================
# Sx —— M5 模块 ATAC 分布散点（FL vs GC，两组重叠 + 离群）
# ============================================================
# RNA 版 M5（上下文对照：mRNA 上调趋势 vs ATAC 不一致）
tg = pd.read_csv(os.path.join(L, "TG_pseudobulk.tsv"), sep=",", index_col=0)
m5g = mod[mod.module == 5].gene.tolist()
m5e = tg.loc[[g for g in m5g if g in tg.index]]
zr = (m5e - m5e.mean(axis=1).values[:, None]) / (m5e.std(axis=1).values[:, None] + 1e-9)
slc_of_col = pd.Series(zr.columns).str.rsplit("_", n=1).str[0].values
rna5 = np.array([zr.loc[:, slc_of_col == s].mean().mean() for s in ORDER])
atac5 = ms["M5"].values

fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.2))
for ax, y, ttl, col in [
    (axes[0], rna5, "M5 module RNA", "#4daf4a"),
    (axes[1], atac5, "M5 module predicted ATAC", "#984ea3")]:
    xs = np.arange(len(ORDER))
    ax.scatter(xs, y, s=80, c=[FC[COND[s]] for s in ORDER], edgecolor="black", linewidth=0.7, zorder=3)
    ax.axhline(0, color="grey", lw=0.8, ls="--")
    for i, s in enumerate(ORDER):
        ax.text(i, y[i] + 0.05, LAB[s], ha="center", fontsize=6.8, color="#333333", rotation=60)
    # 离群标注：与中位数差 > 1.5×IQR
    med = np.median(y); iqr = np.percentile(y,75)-np.percentile(y,25)
    for i, s in enumerate(ORDER):
        if abs(y[i]-med) > 1.5*iqr:
            ax.annotate("outlier", (i, y[i]), textcoords="offset points", xytext=(0, 14),
                        ha="center", fontsize=8, color="#c0392b", fontweight="bold")
    ax.set_xticks(xs); ax.set_xticklabels([])
    ax.set_xlim(-0.6, len(ORDER)-0.4)
    ax.set_ylabel("Module score (z)", fontsize=10)
    ax.set_title(ttl, fontsize=12, fontweight="bold", color=col)
    ax.set_xlabel("Section (FL first, GC second)", fontsize=9.5)
# 重叠性标注
def over_ratio(y):
    fl = y[condA=="FL"]; gc = y[condA=="GC"]
    return (len(fl), len(gc))
for ax, y, name in [(axes[0], rna5, "RNA"), (axes[1], atac5, "ATAC")]:
    fl = y[condA=="FL"]; gc = y[condA=="GC"]
    ax.text(0.03, 0.97, f"FL median {np.median(fl):+.2f} / GC {np.median(gc):+.2f}",
            transform=ax.transAxes, va="top", fontsize=8.5, color="#333333")
leg = [Line2D([0],[0], marker='o', color='w', markerfacecolor=FC["FL"], markersize=9, label='FL (n=6 sections)'),
       Line2D([0],[0], marker='o', color='w', markerfacecolor=FC["GC"], markersize=9, label='GC (n=6 sections)')]
axes[1].legend(handles=leg, loc="lower left", fontsize=9, frameon=False)
fig.suptitle("Supplementary Figure Sx | M5 module distribution across all 12 sections", fontsize=13, fontweight="bold", y=0.99)
fig.text(0.5, 0.005, "z-normalized module score (per gene for RNA, per peak for ATAC). Both groups overlap heavily at the slice level; "
         "the apparent FL-mean shift in predicted ATAC is driven by outlier sections (158_D1 FL, 159_A1 GC).",
         ha="center", fontsize=9, color="#666666")
fig.tight_layout(rect=[0, 0.05, 1, 0.95])
fig.savefig(os.path.join(OUT, "FigS_M5_ATAC_distribution.png"), dpi=300, bbox_inches="tight")
print("[Sx] figures/FigS_M5_ATAC_distribution.png")

# ============================================================
# S2 —— Fig3A 全部模块 NES / FWER 完整表（动物级）
# ============================================================
nes = pd.read_csv(os.path.join(L, "GSEA_NES_animal.txt"), sep="\t")
piv_nes = nes.pivot_table(index="celltype", columns="module", values="NES", aggfunc="first")
piv_p = nes.pivot_table(index="celltype", columns="module", values="FWER_p", aggfunc="first")
s2 = piv_nes.copy()
s2["ct"] = s2.index.map(lambda c: f"ct{c}") if piv_nes.index.dtype != object else piv_nes.index
# 输出完整表：NES + FWER 合并
rows = []
for ct in sorted(piv_nes.index, key=lambda x: int(x)):
    for m in sorted(piv_nes.columns, key=lambda x: int(x.replace("M",""))):
        nesv = piv_nes.loc[ct, m]
        if pd.isna(nesv):
            continue
        rows.append({"celltype": f"ct{ct}", "module": m, "NES": round(nesv,3),
                     "FWER_p": round(piv_p.loc[ct, m],4)})
s2df = pd.DataFrame(rows)
s2df.to_csv(os.path.join(L, "Supp_S2_NES_FWER_full.tsv"), sep="\t", index=False)
print(f"[S2] linger_outputs/Supp_S2_NES_FWER_full.tsv  ({len(s2df)} rows)")
# 渲染为紧凑表（NES + 星号显著性）
sig = (piv_p < 0.05)
disp = piv_nes.copy().round(2).astype(str)
for i in disp.index:
    for j in disp.columns:
        if sig.loc[i, j]:
            disp.loc[i, j] = disp.loc[i, j] + "*"
fig, ax = plt.subplots(figsize=(11, 4.6))
ax.axis("off")
t2 = ax.table(cellText=disp.values, colLabels=disp.columns,
              rowLabels=[f"ct{i}" for i in disp.index], loc="center", cellLoc="center",
              colWidths=[0.07]*len(disp.columns))
t2.auto_set_font_size(False); t2.set_fontsize(8); t2.scale(1, 1.55)
for j in range(len(disp.columns)):
    t2[0, j].set_facecolor("#444444"); t2[0, j].set_text_props(color="white", fontweight="bold")
ax.set_title("Supplementary Table S2 | Animal-level module GSEA (n=3 per group), all modules, NES (FWER p<0.05 marked *)",
             fontsize=11, fontweight="bold", pad=14)
fig.savefig(os.path.join(OUT, "FigS_S2_NES_table.png"), dpi=300, bbox_inches="tight")
print("[S2图] figures/FigS_S2_NES_table.png")

# ============================================================
# S3 —— TF 活性矩阵（成品已在 linger_outputs/TF_activity.txt）
# ============================================================
tfa = pd.read_csv(os.path.join(L, "TF_activity.txt"), sep="\t", index_col=0)
print(f"[S3] TF activity matrix ready: linger_outputs/TF_activity.txt ({tfa.shape[0]} TFs x {tfa.shape[1]} groups)")
print("     -> 投稿时作为 Supplementary Table S3 (full matrix).")
