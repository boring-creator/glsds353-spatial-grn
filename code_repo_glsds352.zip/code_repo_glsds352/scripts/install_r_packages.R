options(repos = c(CRAN = "https://cloud.r-project.org"))
options(timeout = 300)
if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager", quiet = TRUE)
  cat("BiocManager installed\n", flush = TRUE)
}
cat("=== Installing ChIPseeker + TxDb.mm10 ... ===\n", flush = TRUE)
BiocManager::install(
  c("ChIPseeker", "TxDb.Mmusculus.UCSC.mm10.knownGene"),
  update = FALSE, ask = FALSE
)
cat("ChIPseeker:", requireNamespace("ChIPseeker", quietly = TRUE), "\n", flush = TRUE)
cat("TxDb.mm10:", requireNamespace("TxDb.Mmusculus.UCSC.mm10.knownGene", quietly = TRUE), "\n", flush = TRUE)

cat("=== Installing Seurat ... ===\n", flush = TRUE)
if (!requireNamespace("Seurat", quietly = TRUE)) {
  install.packages("Seurat", quiet = TRUE)
}
cat("Seurat:", requireNamespace("Seurat", quietly = TRUE), "\n", flush = TRUE)
cat("=== ALL DONE ===\n", flush = TRUE)
