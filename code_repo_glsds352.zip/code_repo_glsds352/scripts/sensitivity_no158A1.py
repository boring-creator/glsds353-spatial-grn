# -*- coding: utf-8 -*-
"""sensitivity_no158A1.py — 敏感性分析：排除低质量切片 158_A1 后重跑动物级 GSEA
排除 158_A1（F2 的切片之一），F2 用 158_B1 代表。比较排除前后显著组合数/NES 方向。
输出: linger_outputs/GSEA_NES_animal_no158A1.txt
"""
import os
import numpy as np
import pandas as pd
import gseapy as gp

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linger_outputs")
ANIMAL = {"158_A1":"F2","158_B1":"F2","158_C1":"F7","158_D1":"F7",
          "159_C1":"F1","159_D1":"F1","159_A1":"G7","159_B1":"G7",
          "304_A1":"G9","304_B1":"G9","304_C1":"G8","304_D1":"G8"}
FL = {"F1", "F2", "F7"}
EXCLUDE = {"158_A1"}   # 排除的低质量切片

TG = pd.read_csv(os.path.join(BASE, "TG_pseudobulk.tsv"), sep=",", index_col=0)
gdf = pd.DataFrame({"group": TG.columns})
gdf["slice"] = gdf.group.str.rsplit("_", n=1).str[0]
gdf["ct"] = gdf.group.str.rsplit("_", n=1).str[1]
gdf = gdf[~gdf["slice"].isin(EXCLUDE)]           # 排除 158_A1
gdf["animal"] = gdf.slice.map(ANIMAL)
gdf["key"] = gdf.animal + "_" + gdf.ct
TG2 = TG[gdf.group.values]                        # 只保留保留的列
anim_tg = TG2.T.groupby(gdf["key"].values).mean().T
cols = anim_tg.columns
cts = sorted(set(c.rsplit("_", 1)[1] for c in cols))

logFC = pd.DataFrame(index=anim_tg.index)
for ct in cts:
    fl = [c for c in cols if c.rsplit("_", 1)[1] == ct and c.rsplit("_", 1)[0] in FL]
    gc = [c for c in cols if c.rsplit("_", 1)[1] == ct and c.rsplit("_", 1)[0] not in FL]
    if len(fl) and len(gc):
        logFC[ct] = np.log2((anim_tg[fl].mean(axis=1) + 1) / (anim_tg[gc].mean(axis=1) + 1))

modules = pd.read_csv(os.path.join(BASE, "gene_modules.txt"), sep="\t")
module_sets = {f"M{m}": modules[modules.module == m].gene.tolist() for m in range(12)}
rows = []
for ct in logFC.columns:
    r = logFC[ct].dropna()
    if len(r) < 10:
        continue
    pre = gp.prerank(rnk=r.sort_values(ascending=False), gene_sets=module_sets,
                     min_size=3, max_size=2000, permutation_num=1000, seed=42,
                     no_plot=True, outdir=None)
    for _, row in pre.res2d.iterrows():
        rows.append({"celltype": ct, "module": row["Term"],
                     "NES": row["NES"], "FWER_p": row["FWER p-val"]})
nes = pd.DataFrame(rows)
nes.to_csv(os.path.join(BASE, "GSEA_NES_animal_no158A1.txt"), sep="\t", index=None)
sig = nes[nes.FWER_p < 0.05]
print(f"[DONE] 敏感性分析(排除158_A1): {nes.shape[0]} 组合, 显著 {len(sig)}")
print(f"FL-up(NES>0): {(sig.NES>0).sum()}, GC-up(NES<0): {(sig.NES<0).sum()}")
