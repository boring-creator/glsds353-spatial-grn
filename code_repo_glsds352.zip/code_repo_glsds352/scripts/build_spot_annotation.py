# -*- coding: utf-8 -*-
"""build_spot_annotation.py — 合并 RR3 作者注释到我们的 spot（图一用）

输入:
  linger_outputs/RR3_meta.data.tsv  作者 RR3 Seurat 对象 meta.data（barcode 带 _suffix）
  linger_outputs/spot_celltype.tsv   我们 12 切片的 spot + 我们的 Leiden 簇
输出:
  linger_outputs/spot_annotation.tsv  barcode, sample, ct(我们的簇), annot(作者区域),
                                      subgroups, sample_condition
用法: E:/miniconda/envs/valenv/python.exe build_spot_annotation.py
"""
import os
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(BASE, "linger_outputs")

md = pd.read_csv(os.path.join(OUT, "RR3_meta.data.tsv"), sep="\t", index_col=0)
md.index = md.index.astype(str)
# RR3 barcode: 'CATTGCAAAGCATAAT-1_3' → 去后缀 '_3' → 标准 Visium barcode
md["barcode"] = md.index.str.rsplit("_", n=1).str[0]
suffix = md.index.str.rsplit("_", n=1).str[-1]
sec = pd.Series({s: f"Sample_{s.replace('_','')}" for s in []})  # 占位
md["section"] = md["section.name"]
md2 = md[["barcode", "section", "annot", "subgroups", "sample_condition"]].copy()
print("RR3 spots:", len(md2), "| 注释类:", md2.annot.nunique())

# 我们的 spot（含我们的 Leiden 簇）
sp = pd.read_csv(os.path.join(OUT, "spot_celltype.tsv"), sep="\t", index_col=0)
sp = sp.rename(columns={"sample": "section"})  # spot_celltype 的 sample 即切片名
sp["barcode"] = sp.index.astype(str)
print("我们的 spots:", len(sp), "| 切片:", sorted(sp.section.unique()))

# 匹配：我们的 section 名（如 158_A1）→ RR3 section（Sample_158_A1）
m = sp.merge(md2[["barcode", "section", "annot", "subgroups", "sample_condition"]],
             on="barcode", how="left",
             suffixes=("_ours", "_rr3"))
# 校验 section 一致性：只有 RR3 section 与我们的 section 对应才保留（避免 barcode 跨切片误配）
m = m[(m.section_ours == m.section_rr3.str.replace("Sample_", "")) | m.section_rr3.isna()]
m = m.drop(columns=["section_rr3"]).rename(columns={"section_ours": "section"})
m = m[["barcode", "section", "celltype", "annot", "subgroups", "sample_condition"]]
m.columns = ["barcode", "section", "ct_ours", "annot_rr3", "subgroups_rr3", "cond_rr3"]
m.to_csv(os.path.join(OUT, "spot_annotation.tsv"), sep="\t", index=None)
print("合并后:", m.shape)
print("annot_rr3 覆盖率: %.1f%%" % (100 * m.annot_rr3.notna().mean()))
print("FL/GC:", m.cond_rr3.value_counts().to_dict())
print("\n每切片 annot 覆盖:")
print(m.groupby("section").apply(lambda g: round(100 * g.annot_rr3.notna().mean(), 1)).to_string())
