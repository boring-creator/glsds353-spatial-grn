# -*- coding: utf-8 -*-
"""sweep_resolution.py — Leiden 分辨率扫描，选细胞类型数。

Harmony 嵌入只算一次，Leiden 在 4 个分辨率下对比，报告：
  - 聚类数
  - 切片×细胞类型 非空组数（伪 bulk 列数）
  - 极小组分布（spot<20 / <50 的组占比，均值/中位数组大小）

选型标准（写进 Methods）：类别数可解释（海马 ~10-20 类）且极小组尽量少。
"""
import os
import numpy as np
import pandas as pd
import scanpy as sc
from anndata import concat

SLICES = ["158_A1","158_B1","158_C1","158_D1","159_A1","159_B1","159_C1","159_D1",
          "304_A1","304_B1","304_C1","304_D1"]
DATA = "/root/autodl-tmp/ison_data"

print("[1] 读入 + 预处理 ...", flush=True)
rna_list = []
for s in SLICES:
    r = sc.read_h5ad(f"{DATA}/{s}/output_v2/{s}-RNA.h5ad")
    r.obs["sample"] = s
    rna_list.append(r)
rna = concat(rna_list, join="outer")
rna.X = np.nan_to_num(np.asarray(rna.X, dtype=np.float32))

adata = rna.copy()
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.pca(adata, n_comps=30)

print("[2] Harmony 批校正（一次）...", flush=True)
import harmonypy as hm
ho = hm.run_harmony(adata.obsm["X_pca"], adata.obs[["sample"]], "sample",
                    max_iter_harmony=20, verbose=False, random_state=0)
Z = np.asarray(ho.Z_corr)
adata.obsm["X_pca_harmony"] = Z if Z.shape[0] == adata.n_obs else Z.T
sc.pp.neighbors(adata, use_rep="X_pca_harmony", n_neighbors=15)
print(f"    嵌入 {adata.obsm['X_pca_harmony'].shape}", flush=True)

print("\n[3] 分辨率扫描 ...", flush=True)
print(f"{'res':>5s} {'聚类数':>5s} {'伪bulk组':>6s} {'组<20spot':>9s} {'组<50spot':>9s} {'组中位spot':>9s} {'组最小spot':>9s}")
for res in [0.3, 0.5, 0.8, 1.0]:
    sc.tl.leiden(adata, resolution=res, key_added="ct", flavor="leidenalg")
    ct = adata.obs["ct"].values
    smp = adata.obs["sample"].values
    # 切片×细胞类型 组的 spot 数
    df = pd.DataFrame({"sample": smp, "ct": ct})
    sizes = df.groupby(["sample", "ct"]).size()
    n_groups = len(sizes)
    tiny20 = (sizes < 20).mean() * 100
    tiny50 = (sizes < 50).mean() * 100
    med = sizes.median()
    mn = sizes.min()
    print(f"{res:>5.1f} {len(np.unique(ct)):>5d} {n_groups:>6d} {tiny20:>8.1f}% {tiny50:>8.1f}% {med:>9.0f} {mn:>9d}")

print("\n[DONE] 扫描完成")
