# validate_20kb_fisher.R — 验证②：Peak-基因 20kb 邻近性 Fisher（论文 Fig S23a 同款）
# 用 ChIPseeker 注释 peak → 每模块 Fisher 检验：模块内 peak 是否倾向近邻（≤20kb）模块内基因
suppressMessages({
  library(ChIPseeker)
  library(GenomicFeatures)
})

# 1. 加载 mm10 TxDb
txdb <- loadDb("C:/Users/aguang/Downloads/Desktop/sci/mm10_txdb.sqlite")
cat("TxDb loaded\n", flush = TRUE)

# 2. 读 peaks（chr:start-end）
peaks_txt <- readLines("C:/Users/aguang/Downloads/Desktop/sci/linger_outputs/Peaks.txt")
peaks_txt <- peaks_txt[nchar(peaks_txt) > 0]
gr <- GRanges(
  seqnames = sub(":.*", "", peaks_txt),
  ranges = IRanges(
    start = as.integer(sub(".*:(\\d+)-.*", "\\1", peaks_txt)),
    end = as.integer(sub(".*-(\\d+)$", "\\1", peaks_txt))
  )
)
names(gr) <- peaks_txt
# 过滤非标准染色体（GL/JH contig，TxDb 无注释）
keep <- seqnames(gr) %in% paste0("chr", c(1:19, "X", "Y"))
gr <- gr[keep]
cat("peaks:", length(gr), "\n", flush = TRUE)

# 3. annotatePeak → 每个 peak 最近基因 + 距离（geneId 是 Ensembl ID → 映射 symbol）
anno <- annotatePeak(gr, TxDb = txdb, level = "gene", assignGenomicAnnotation = TRUE, verbose = FALSE)
df <- as.data.frame(anno)
suppressMessages(library(org.Mm.eg.db))
ens <- sub("\\..*$", "", df$geneId)
sym <- mapIds(org.Mm.eg.db, keys = ens, keytype = "ENSEMBL", column = "SYMBOL", multiVals = "first")
peak_gene <- data.frame(
  peak = names(gr),
  gene = as.character(sym),
  dist = abs(df$distanceToTSS),
  stringsAsFactors = FALSE
)
cat("注释完成，有基因 symbol 的 peak:", sum(!is.na(peak_gene$gene)), "\n", flush = TRUE)

# 4. 模块分配
peak_mod <- read.table("C:/Users/aguang/Downloads/Desktop/sci/module_assign_peak.tsv", header = TRUE, sep = "\t")
gene_mod <- read.table("C:/Users/aguang/Downloads/Desktop/sci/module_assign_gene.tsv", header = TRUE, sep = "\t")
n_mod <- max(peak_mod$module, gene_mod$module) + 1
cat("模块数:", n_mod, "\n", flush = TRUE)

# 5. 每模块 Fisher
cat("=== 每模块 20kb Fisher ===\n")
results <- data.frame()
for (k in 0:(n_mod - 1)) {
  pk_this <- peak_mod$peak[peak_mod$module == k]
  gn_this <- unique(gene_mod$gene[gene_mod$module == k])
  sub <- peak_gene[peak_gene$peak %in% pk_this & !is.na(peak_gene$gene), ]
  if (nrow(sub) < 5) next
  near20 <- sub$dist <= 20000
  same_mod <- sub$gene %in% gn_this
  a <- sum(near20 & same_mod)
  b <- sum(near20 & !same_mod)
  c <- sum(!near20 & same_mod)
  d <- sum(!near20 & !same_mod)
  tab <- matrix(c(a, b, c, d), nrow = 2)
  ft <- fisher.test(tab, alternative = "greater")
  results <- rbind(results, data.frame(module = k, n_peaks = nrow(sub),
                                       a = a, b = b, c = c, d = d,
                                       OR = ft$estimate, p = ft$p.value))
}
results$adj_p <- p.adjust(results$p, method = "BH")
print(results, row.names = FALSE)
cat("显著模块数 (adj_p<0.05):", sum(results$adj_p < 0.05), "\n")
write.csv(results, "C:/Users/aguang/Downloads/Desktop/sci/linger_outputs/fisher20kb_results.csv", row.names = FALSE)
cat("[SAVED] linger_outputs/fisher20kb_results.csv\n")
