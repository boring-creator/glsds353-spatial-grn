# GLDS-352 spatial gene-regulatory workflow

Analysis scripts for:

**A reproducible workflow for spatial gene-regulatory analysis integrating predicted chromatin accessibility and single-cell-multiome-based network inference, applied to the spaceflight mouse hippocampus**

Nurlanjan Mutalipjan, Bowen Ding (Xinjiang Medical University, Urumqi, China)

## Overview

This repository contains the scripts used to predict spatial chromatin accessibility and infer spatially resolved gene regulatory networks (GRNs) in the mouse hippocampus, using 12 Visium sections from the NASA Rodent Research-3 (RR-3) mission (OSDR study **GLDS-352**).

The workflow has four stages:
1. **Spatial accessibility prediction** with [ISON](https://github.com/Durenlab/ISON) (Debnath & Duren, 2026), from spatial transcriptomics + a single-cell multiome reference.
2. **Spatially resolved GRN inference** with [LINGER](https://github.com/Durenlab/LINGER) (Yuan & Duren, 2025), producing cis-/trans-regulatory interactions and transcription-factor (TF) activity scores.
3. **Regulatory modules and animal-level GSEA** (K-means modules + preranked GSEA, FWER-adjusted).
4. **Validation and sensitivity** (spatial autocorrelation, cross-modality agreement, marker co-localization, within-batch consistency, inter-individual-variability separation analysis).

## Data

All input data are public:

- **GLDS-352** (Rodent Research-3): 12 hippocampal Visium sections (3 flight, 3 ground control; 2 consecutive sections per animal) + 5-sample single-cell multiome (snRNA + snATAC) reference. https://osdr.nasa.gov/bio/study/GLDS-352
- Original study's spatial annotations: https://github.com/giacomellolab/NASA_RR3_Brain
- ISON and LINGER are run in their respective published environments (see below).

## Environment

| Software | Version / notes |
|---|---|
| Python | 3.11 (`valenv` for local analysis; scripts assume a conda env with the packages below) |
| Python packages | Scanpy 1.11.5, squidpy 1.8.2, anndata 0.12.19, gseapy 1.3.1 |
| R | 4.3.2 (ggplot2, patchwork, clusterProfiler, ChIPseeker, org.Mm.eg.db) |
| ISON | Python 3.9 + torch (see ISON repository) |
| LINGER / scNN | `scnn_paper` environment (SHAP 0.42.1, torch 2.1) |

The ISON and LINGER runs require GPU compute and are executed in the environments of the respective tools; the scripts here prepare inputs, call the tools, and process outputs.

> **Note on paths**: all scripts contain absolute local paths (e.g. `E:/space/ison_data/`, `E:/miniconda/...`). These must be adapted to your environment before re-running.

## Pipeline scripts

### 0. Environment setup (R)
| Script | Purpose |
|---|---|
| `install_r_packages.R` | Install R packages (ChIPseeker, clusterProfiler, org.Mm.eg.db, DESeq2, ggplot2, patchwork) |
| `build_txdb_mm10.R` | Build a mm10 TxDb from RefSeq GTF |

### 1. Data preparation
| Script | Purpose |
|---|---|
| `prepare_data.py` | Build ISON input matrices (top-80% gene filter, following the ISON protocol) |
| `rebuild_reference_tf.py` | Rebuild the multiome reference retaining all 217 transcription factors |
| `sweep_resolution.py` | Leiden resolution sweep to choose the number of cell-type clusters |
| `build_spot_annotation.py` | Merge the original study's region/cell-type annotations onto Visium spots |
| `build_linger_inputs.py` | Convert ISON outputs to LINGER pseudobulk inputs (TG/RE) |
| `build_atac_pseudobulk.py` | Build predicted-ATAC pseudobulk counts |
| `recompute_ref_anchor.py` | Recompute per-spot reference-anchored accessibility correlation |

### 2. GRN inference (LINGER / scNN)
| Script | Purpose |
|---|---|
| `run_scnn_parallel.py` | scNN training (parallel, per chromosome) |
| `run_scnn.py` / `run_chr.py` | scNN training (serial / single chromosome) |
| `run_grn.py` | Assemble cis-/trans-regulatory interactions and TF activity from scNN outputs |
| `run_downstream.py` | K-means modules + logFC + GSEA (cloud version) |

### 3. Differential analysis (animal-level)
| Script | Purpose |
|---|---|
| `compute_animal_gsea.py` | **Animal-level GSEA** (main result; avoids pseudoreplication from paired sections) |
| `run_gsea_local.py` | Section-level GSEA (earlier version) |
| `run_159_control.py` | Within-batch 159 control (FL vs GC within a single sequencing batch) |
| `run_go_enrichment.py` | GO enrichment of regulatory modules (gseapy Enrichr, GO_BP_2025) |
| `batch_within.py` | Within-batch animal comparisons (batch 158 and 304) |
| `sensitivity_no158A1.py` | Sensitivity analysis excluding the low-quality section 158_A1 |

### 4. Validation of predicted accessibility
| Script | Purpose |
|---|---|
| `validate_moran.py` | Moran's I spatial autocorrelation |
| `validate_ref_pseudo_atac.py` | Cross-modality agreement (reference-anchored, NNLS deconvolution) |
| `validate_marker_enhancer.R` | Marker-gene / promoter-enhancer co-localization |
| `validate_module_consistency.py` | RNA–ATAC module consistency (weak validation) |
| `validate_20kb_fisher.R` | 20 kb peak–gene Fisher association (weak validation) |
| `validate_distance_decay.py` | Cis-regulatory distance decay (weak validation) |

### 5. Figures
| Script | Output |
|---|---|
| `plot_fig1.R` | Fig. 1 spatial overview |
| `plot_fig2.R` | Fig. 2 validation (Moran's I / agreement / marker co-localization) |
| `plot_fig3.R` | Fig. 3 GO bubble plot |
| `run_nes_heatmap.R` | Fig. 4 NES heatmap (animal-level + direction-only) |
| `plot_fig6.R` | Fig. 5 mechanism (TF activity / TF×module / subregion) |
| `plot_fig5.R` | Fig. 6 key stress-response genes |
| `plot_figs.R` | Supplementary weak-validation figures |
| `plot_marker_spatial.R` | Marker co-localization spatial maps |
| `generate_marker_159.py` | Batch-159 marker spatial data |
| `make_supp_figs.py` | Supplementary tables/figures S1/Sx/S2/S3 |
| `make_graphical_abstract.py` | Graphical abstract |

> Note: script names do not always match figure numbers — `plot_fig5.R` produces the figure labeled 6 and `plot_fig6.R` produces the figure labeled 5; see headers in each script.

## Quick reproduction (main results)

```bash
# Environment: valenv (Python 3.11)
python compute_animal_gsea.py        # animal-level GSEA (main result)
python run_go_enrichment.py          # GO enrichment
python run_159_control.py            # within-batch 159 control
python batch_within.py               # within-batch animal comparisons
python sensitivity_no158A1.py        # sensitivity (exclude 158_A1)
python make_supp_figs.py             # supplementary materials

# R figures
Rscript plot_fig1.R; Rscript plot_fig2.R; Rscript plot_fig3.R
Rscript run_nes_heatmap.R; Rscript plot_fig6.R; Rscript plot_fig5.R; Rscript plot_figs.R

# Graphical abstract
python make_graphical_abstract.py
```

## Data files / supplementary outputs

The main results (Supplementary Tables S1–S3, sensitivity analyses) are provided with the manuscript and in `Supplementary_data/` of the submission. Key outputs include:
- `GSEA_NES_animal*` — animal-level GSEA results
- `batch_within_comparison.tsv` — within-batch comparisons (Supplementary Analysis S-2)
- `Supp_S1_module_ATAC.tsv`, `Supp_S2_NES_FWER_full.tsv`, `TF_activity.txt`

## License

MIT License (see LICENSE).

## Citation

If you use this workflow, please cite:
- The manuscript (Mutalipjan & Ding, submitted to *Life Sciences in Space Research*)
- ISON: Debnath & Duren, *Nature Communications* 2026, 17, 7172.
- LINGER: Yuan & Duren, *Nature Biotechnology* 2025, 43, 247–257.
