# Data

All raw data are public and are NOT redistributed in this repository.

## Source
- **GLDS-352** (NASA Rodent Research-3): 12 hippocampal Visium sections (3 flight, 3 ground control; two consecutive sections per animal) and a 5-sample single-cell multiome (snRNA + snATAC) reference (32,243 cells).
  - https://osdr.nasa.gov/bio/study/GLDS-352
- Original study's spatial annotations (Seurat object): https://github.com/giacomellolab/NASA_RR3_Brain

## Reference implementation
- ISON: https://github.com/Durenlab/ISON
- LINGER: https://github.com/Durenlab/LINGER

## Analysis outputs (provided with the manuscript)
The main result tables are available as supplementary materials with the manuscript:
- `Supp_S1_module_ATAC.tsv` — module-normalized predicted accessibility per section (Supplementary Table S1)
- `Supp_S2_NES_FWER_full.tsv` — complete animal-level GSEA output (Supplementary Table S2)
- `TF_activity.txt` — full TF activity matrix (Supplementary Table S3)
- `GSEA_NES_animal_no158A1.txt` — sensitivity analysis excluding 158_A1 (Supplementary Analysis S-1)
- `batch_within_comparison.tsv` — within-batch animal comparisons (Supplementary Analysis S-2)
